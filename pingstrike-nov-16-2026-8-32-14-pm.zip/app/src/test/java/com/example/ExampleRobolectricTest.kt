package com.example

import android.content.Context
import android.content.pm.PackageManager
import androidx.test.core.app.ApplicationProvider
import com.example.model.GameApp
import com.example.model.OptimizationToggles
import com.example.model.PingQuality
import com.example.model.PingServer
import com.example.model.ShizukuState
import com.example.service.NetworkOptimizerService
import com.example.shizuku.ShizukuManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PingStrike", appName)
  }

  @Test
  fun `verify ShizukuProvider is registered in manifest`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val pkgInfo = context.packageManager.getPackageInfo(
      context.packageName,
      PackageManager.GET_PROVIDERS
    )
    val providers = pkgInfo.providers?.map { it.name } ?: emptyList()
    assertTrue("ShizukuProvider must be registered in AndroidManifest", providers.contains("rikka.shizuku.ShizukuProvider"))
  }

  @Test
  fun `verify ping quality calculation`() {
    val serverFast = PingServer("test", "Fast Server", "US", "1.1.1.1", "Edge", 22)
    assertEquals(PingQuality.EXCELLENT, serverFast.quality)

    val serverModerate = PingServer("test2", "Mod Server", "US", "1.1.1.1", "Edge", 75)
    assertEquals(PingQuality.FAIR, serverModerate.quality)
  }

  @Test
  fun `verify shizuku simulation mode and strike mode execution`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = ShizukuManager(context)
    manager.setSimulationMode(true)
    assertEquals(ShizukuState.SIMULATED, manager.shizukuState.value)

    val service = NetworkOptimizerService(context, manager)
    val result = service.applyStrikeMode(
      game = GameApp("com.tencent.ig", "PUBG Mobile"),
      toggles = OptimizationToggles(),
      selectedDnsHost = "one.one.one.one",
      frozenApps = listOf("com.instagram.android")
    )
    assertTrue(result.appliedCount > 0)
    assertEquals(result.totalCount, result.appliedCount)
    assertNotNull(result.summaryLines)
  }
}
