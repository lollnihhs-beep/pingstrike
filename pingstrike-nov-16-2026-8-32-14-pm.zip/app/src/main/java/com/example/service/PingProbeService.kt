package com.example.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import com.example.model.DeviceTelemetry
import com.example.model.DnsBenchmarkItem
import com.example.model.NetworkDetails
import com.example.model.PingServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.roundToInt

class PingProbeService(private val context: Context) {

    suspend fun probeHost(host: String, port: Int = 443, timeoutMs: Int = 1500): Int = withContext(Dispatchers.IO) {
        val icmpResult = runIcmpPing(host, timeoutSeconds = 1)
        if (icmpResult > 0) return@withContext icmpResult

        val tcpResult = runTcpHandshake(host, port, timeoutMs)
        if (tcpResult > 0) return@withContext tcpResult

        val altResult = runTcpHandshake(host, 80, timeoutMs)
        if (altResult > 0) return@withContext altResult

        -1
    }

    private fun runIcmpPing(host: String, timeoutSeconds: Int = 1): Int {
        return try {
            val process = Runtime.getRuntime().exec(
                arrayOf("/system/bin/ping", "-c", "1", "-W", "$timeoutSeconds", host)
            )
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            var ping = -1
            while (reader.readLine().also { line = it } != null) {
                val l = line ?: continue
                if (l.contains("time=")) {
                    val index = l.indexOf("time=")
                    val sub = l.substring(index + 5)
                    val msStr = sub.split(" ")[0].trim()
                    ping = msStr.toDoubleOrNull()?.roundToInt() ?: -1
                }
            }
            process.waitFor()
            ping
        } catch (e: Exception) {
            -1
        }
    }

    private fun runTcpHandshake(host: String, port: Int, timeoutMs: Int): Int {
        var socket: Socket? = null
        return try {
            val start = System.nanoTime()
            socket = Socket()
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            val elapsedMs = ((System.nanoTime() - start) / 1_000_000.0).roundToInt()
            elapsedMs.coerceAtLeast(1)
        } catch (e: Exception) {
            -1
        } finally {
            try {
                socket?.close()
            } catch (ignored: Exception) {}
        }
    }

    suspend fun benchmarkServers(servers: List<PingServer>): List<PingServer> = withContext(Dispatchers.IO) {
        servers.map { server ->
            async {
                val ping = probeHost(server.host)
                val jitter = if (ping > 0 && server.currentPingMs > 0) {
                    abs(ping - server.currentPingMs)
                } else {
                    0
                }
                server.copy(
                    currentPingMs = ping,
                    jitterMs = if (ping > 0) jitter else 0,
                    packetLossPct = if (ping > 0) 0 else 100,
                    isTesting = false
                )
            }
        }.awaitAll()
    }

    suspend fun benchmarkDnsProviders(providers: List<DnsBenchmarkItem>): List<DnsBenchmarkItem> = withContext(Dispatchers.IO) {
        providers.map { dns ->
            async {
                if (dns.hostname == "opportunistic") {
                    return@async dns.copy(latencyMs = probeHost("8.8.8.8", port = 53, timeoutMs = 1200), isTesting = false)
                }
                val latency = probeHost(dns.hostname, port = 53, timeoutMs = 1200)
                val finalLatency = if (latency > 0) latency else probeHost(dns.hostname, port = 443, timeoutMs = 1200)
                dns.copy(
                    latencyMs = finalLatency,
                    isTesting = false
                )
            }
        }.awaitAll()
    }

    fun getDeviceTelemetry(): DeviceTelemetry {
        val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = if (Build.MODEL.startsWith(brand, ignoreCase = true)) Build.MODEL else "$brand ${Build.MODEL}"
        val androidVer = "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"
        val patch = Build.VERSION.SECURITY_PATCH.ifBlank { "Unknown" }
        val kernel = System.getProperty("os.version")?.substringBefore("-") ?: "Linux"
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        return DeviceTelemetry(
            deviceModel = model,
            androidVersion = androidVer,
            securityPatch = patch,
            kernelVersion = kernel,
            abi = abi
        )
    }

    fun getNetworkDetails(): NetworkDetails {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

            val activeNetwork = cm?.activeNetwork
            val capabilities = cm?.getNetworkCapabilities(activeNetwork)
            val linkProps = cm?.getLinkProperties(activeNetwork)

            val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ?: false
            val iface = linkProps?.interfaceName ?: if (isWifi) "wlan0" else "rmnet_data0"
            val ipv4 = linkProps?.linkAddresses
                ?.mapNotNull { it.address as? Inet4Address }
                ?.firstOrNull()
                ?.hostAddress ?: "—"

            val dns = linkProps?.privateDnsServerName?.takeIf { it.isNotBlank() }
                ?: linkProps?.dnsServers?.firstOrNull()?.hostAddress
                ?: "Automatic"

            val gateway = linkProps?.routes?.firstOrNull { it.isDefaultRoute }?.gateway?.hostAddress ?: "—"

            if (isWifi && wm != null) {
                @Suppress("DEPRECATION")
                val info = wm.connectionInfo
                val speed = if (info != null && info.linkSpeed > 0) info.linkSpeed else 0
                val rssi = info?.rssi ?: 0
                val freq = info?.frequency ?: 0

                NetworkDetails(
                    isWifi = true,
                    interfaceName = iface,
                    ipAddress = if (ipv4 != "—") ipv4 else formatIpAddress(info?.ipAddress ?: 0),
                    linkSpeedMbps = speed,
                    frequencyMhz = freq,
                    rssiDbm = rssi,
                    dnsServer = dns,
                    gateway = gateway
                )
            } else {
                NetworkDetails(
                    isWifi = false,
                    interfaceName = iface,
                    ipAddress = ipv4,
                    linkSpeedMbps = 0,
                    frequencyMhz = 0,
                    rssiDbm = 0,
                    dnsServer = dns,
                    gateway = gateway
                )
            }
        } catch (e: Exception) {
            NetworkDetails()
        }
    }

    private fun formatIpAddress(ip: Int): String {
        return if (ip == 0) "—"
        else "${ip and 0xFF}.${ip shr 8 and 0xFF}.${ip shr 16 and 0xFF}.${ip shr 24 and 0xFF}"
    }
}
