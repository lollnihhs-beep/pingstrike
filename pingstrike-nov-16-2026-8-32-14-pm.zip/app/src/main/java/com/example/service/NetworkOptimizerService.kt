package com.example.service

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.example.model.GameApp
import com.example.model.OptimizationResult
import com.example.model.OptimizationToggles
import com.example.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NetworkOptimizerService(
    private val context: Context,
    private val shizukuManager: ShizukuManager
) {

    suspend fun applyStrikeMode(
        game: GameApp,
        toggles: OptimizationToggles,
        selectedDnsHost: String?,
        frozenApps: List<String>
    ): OptimizationResult = withContext(Dispatchers.IO) {
        var applied = 0
        var total = 0
        val summary = mutableListOf<String>()

        suspend fun runStep(label: String, command: String): Boolean {
            total++
            val res = shizukuManager.executeCommand(command)
            if (res.isSuccess) {
                applied++
                summary.add("✓ $label")
            } else {
                summary.add("✗ $label (${res.output.take(40)})")
            }
            return res.isSuccess
        }

        // 1. Eliminate Wi-Fi Scan Latency Spikes
        if (toggles.disableWifiScanSpikes) {
            runStep("Disable background Wi-Fi scanning", "settings put global wifi_scan_always_enabled 0")
            runStep("WifiService scan-always disabled", "cmd wifi set-scan-always-available disabled")
        }

        // 2. Wi-Fi Hardware Low-Latency & High-Performance Mode
        if (toggles.wifiLowLatencyMode) {
            runStep("Wi-Fi HAL low-latency mode", "cmd wifi force-low-latency-mode enabled")
            runStep("Wi-Fi high-performance lock", "cmd wifi force-hi-perf-mode enabled")
            runStep("Wi-Fi keep-alive policy", "settings put global wifi_sleep_policy 2")
        }

        // 3. Disable BLE background radio scans (reduces 2.4GHz/combo chip contention)
        if (toggles.disableBleScanSpikes) {
            runStep("Disable BLE background scan", "settings put global ble_scan_always_enabled 0")
        }

        // 4. Mobile Data Always On (Zero packet drop failover)
        if (toggles.mobileDataAlwaysOn) {
            runStep("Mobile data instant failover", "settings put global mobile_data_always_on 1")
        }

        // 5. TCP Initial Window Tuning (works via settings provider under UID 2000)
        if (toggles.tcpBufferPacing) {
            runStep("TCP initial rwnd window (60)", "settings put global tcp_default_init_rwnd 60")
        }

        // 6. Private Gaming DNS
        if (!selectedDnsHost.isNullOrBlank() && selectedDnsHost != "opportunistic") {
            val modeOk = runStep("Private DNS strict hostname mode", "settings put global private_dns_mode hostname")
            if (modeOk) {
                runStep("Private DNS ($selectedDnsHost)", "settings put global private_dns_specifier $selectedDnsHost")
            }
        }

        // 7. Game Manager Performance Mode & Priority
        if (toggles.gameModePerformance) {
            runStep("Game performance mode (${game.name})", "cmd game mode performance ${game.packageName}")
            runStep("Whitelist game from Doze throttling", "cmd deviceidle whitelist +${game.packageName}")
            runStep("Fixed performance mode", "cmd power set-fixed-performance-mode-enabled true")
            runStep("Promote game to ACTIVE bucket", "am set-standby-bucket ${game.packageName} active")
            runStep("Allow unrestricted game background", "cmd appops set ${game.packageName} RUN_ANY_IN_BACKGROUND allow")
        }

        // 8. Restrict Background Network Bandwidth (NetPolicy Data Saver with Game + Self Whitelist)
        if (toggles.restrictBackgroundData) {
            val gameUid = getPackageUid(game.packageName)
            val selfUid = getPackageUid(context.packageName)
            if (selfUid > 0) {
                shizukuManager.executeCommand("cmd netpolicy add restrict-background-whitelist $selfUid")
            }
            if (gameUid > 0) {
                runStep("Whitelist ${game.name} UID", "cmd netpolicy add restrict-background-whitelist $gameUid")
            }
            runStep("Restrict background data firewall", "cmd netpolicy set restrict-background true")
        }

        // 9. Throttle & Stop Background Bandwidth Consumers
        if (toggles.aggressiveStandbyBuckets && frozenApps.isNotEmpty()) {
            var restrictedCount = 0
            for (pkg in frozenApps) {
                val r1 = shizukuManager.executeCommand("am set-standby-bucket $pkg restricted")
                shizukuManager.executeCommand("cmd appops set $pkg RUN_IN_BACKGROUND ignore")
                shizukuManager.executeCommand("cmd appops set $pkg RUN_ANY_IN_BACKGROUND ignore")
                if (toggles.forceStopBackgroundApps) {
                    shizukuManager.executeCommand("am force-stop $pkg")
                }
                if (r1.isSuccess) restrictedCount++
            }
            total++
            if (restrictedCount > 0) {
                applied++
                summary.add("✓ Throttled $restrictedCount/${frozenApps.size} background apps")
            } else {
                summary.add("✗ Failed to restrict background apps")
            }
        }

        // 10. Flush cached background processes
        if (toggles.forceStopBackgroundApps) {
            runStep("Clear cached background processes", "am kill-all")
        }

        OptimizationResult(
            appliedCount = applied,
            totalCount = total,
            summaryLines = summary,
            isSimulated = shizukuManager.isSimulatedMode.value
        )
    }

    suspend fun restoreDefaults(
        game: GameApp,
        frozenApps: List<String>
    ): OptimizationResult = withContext(Dispatchers.IO) {
        var restored = 0
        var total = 0
        val summary = mutableListOf<String>()

        suspend fun runRestore(label: String, command: String) {
            total++
            val res = shizukuManager.executeCommand(command)
            if (res.isSuccess) {
                restored++
                summary.add("✓ $label")
            }
        }

        runRestore("Restore Wi-Fi scanning", "settings put global wifi_scan_always_enabled 1")
        runRestore("WifiService scan-always enabled", "cmd wifi set-scan-always-available enabled")
        runRestore("Disable Wi-Fi low-latency lock", "cmd wifi force-low-latency-mode disabled")
        runRestore("Disable Wi-Fi hi-perf lock", "cmd wifi force-hi-perf-mode disabled")
        runRestore("Restore BLE scanning", "settings put global ble_scan_always_enabled 1")
        runRestore("Restore Private DNS (Automatic)", "settings put global private_dns_mode opportunistic")
        runRestore("Disable background netpolicy restriction", "cmd netpolicy set restrict-background false")
        runRestore("Disable fixed performance mode", "cmd power set-fixed-performance-mode-enabled false")
        runRestore("Set game mode to standard", "cmd game mode standard ${game.packageName}")

        if (frozenApps.isNotEmpty()) {
            total++
            var count = 0
            for (pkg in frozenApps) {
                val r = shizukuManager.executeCommand("am set-standby-bucket $pkg working_set")
                shizukuManager.executeCommand("cmd appops set $pkg RUN_IN_BACKGROUND allow")
                shizukuManager.executeCommand("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow")
                if (r.isSuccess) count++
            }
            if (count > 0) {
                restored++
                summary.add("✓ Restored $count background apps")
            }
        }

        OptimizationResult(
            appliedCount = restored,
            totalCount = total,
            summaryLines = summary,
            isSimulated = shizukuManager.isSimulatedMode.value
        )
    }

    suspend fun applyPrivateDns(hostname: String): Boolean = withContext(Dispatchers.IO) {
        if (hostname.isEmpty() || hostname == "opportunistic") {
            shizukuManager.executeCommand("settings put global private_dns_mode opportunistic").isSuccess
        } else {
            val r1 = shizukuManager.executeCommand("settings put global private_dns_mode hostname")
            val r2 = shizukuManager.executeCommand("settings put global private_dns_specifier $hostname")
            r1.isSuccess && r2.isSuccess
        }
    }

    suspend fun freezeApp(packageName: String): Boolean = withContext(Dispatchers.IO) {
        val r1 = shizukuManager.executeCommand("am set-standby-bucket $packageName restricted")
        shizukuManager.executeCommand("cmd appops set $packageName RUN_IN_BACKGROUND ignore")
        shizukuManager.executeCommand("cmd appops set $packageName RUN_ANY_IN_BACKGROUND ignore")
        val r2 = shizukuManager.executeCommand("am force-stop $packageName")
        r1.isSuccess || r2.isSuccess
    }

    suspend fun unfreezeApp(packageName: String): Boolean = withContext(Dispatchers.IO) {
        val r1 = shizukuManager.executeCommand("am set-standby-bucket $packageName working_set")
        val r2 = shizukuManager.executeCommand("cmd appops set $packageName RUN_IN_BACKGROUND allow")
        shizukuManager.executeCommand("cmd appops set $packageName RUN_ANY_IN_BACKGROUND allow")
        r1.isSuccess || r2.isSuccess
    }

    private fun getPackageUid(packageName: String): Int {
        return try {
            val pm = context.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageUid(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageUid(packageName, 0)
            }
        } catch (e: Exception) {
            -1
        }
    }
}
