package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.BackgroundTasksScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.NetworkOptimizerScreen
import com.example.ui.screens.ShizukuTerminalScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.NavBarSurface
import com.example.ui.theme.NavPillActive
import com.example.ui.theme.PingStrikeTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.PingBoosterViewModel

enum class NavigationTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    DASHBOARD("Home", Icons.Filled.Home, Icons.Outlined.Home, "tab_dashboard"),
    NETWORK("Network", Icons.Filled.NetworkCheck, Icons.Outlined.NetworkCheck, "tab_network"),
    TASKS("Tasks", Icons.Filled.Memory, Icons.Outlined.Memory, "tab_tasks"),
    TERMINAL("Shell", Icons.Filled.Terminal, Icons.Outlined.Terminal, "tab_terminal")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PingStrikeTheme {
                val viewModel: PingBoosterViewModel = viewModel()
                var currentTab by remember { mutableStateOf(NavigationTab.DASHBOARD) }

                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            viewModel.shizukuManager.checkStatus()
                            viewModel.refreshNetworkDetails()
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                BackHandler(enabled = currentTab != NavigationTab.DASHBOARD) {
                    currentTab = NavigationTab.DASHBOARD
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    containerColor = DarkBackground
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            NavigationTab.DASHBOARD -> DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToNetwork = { currentTab = NavigationTab.NETWORK },
                                onNavigateToTasks = { currentTab = NavigationTab.TASKS }
                            )
                            NavigationTab.NETWORK -> NetworkOptimizerScreen(viewModel = viewModel)
                            NavigationTab.TASKS -> BackgroundTasksScreen(viewModel = viewModel)
                            NavigationTab.TERMINAL -> ShizukuTerminalScreen(viewModel = viewModel)
                        }

                        // Floating Pill Navigation Bar (responsive for narrow floating windows & tablets)
                        androidx.compose.foundation.layout.BoxWithConstraints(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .navigationBarsPadding()
                                .padding(horizontal = 12.dp, vertical = 14.dp)
                        ) {
                            val isCompactWindow = maxWidth < 340.dp
                            Row(
                                modifier = Modifier
                                    .shadow(16.dp, RoundedCornerShape(32.dp))
                                    .clip(RoundedCornerShape(32.dp))
                                    .background(NavBarSurface)
                                    .border(1.dp, DarkBorder, RoundedCornerShape(32.dp))
                                    .padding(
                                        horizontal = if (isCompactWindow) 6.dp else 8.dp,
                                        vertical = 6.dp
                                    )
                                    .testTag("bottom_nav_bar"),
                                horizontalArrangement = Arrangement.spacedBy(if (isCompactWindow) 2.dp else 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                NavigationTab.entries.forEach { tab ->
                                    val selected = currentTab == tab
                                    Box(
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .clip(RoundedCornerShape(24.dp))
                                            .background(if (selected) NavPillActive else Color.Transparent)
                                            .clickable { currentTab = tab }
                                            .padding(
                                                horizontal = if (isCompactWindow) 12.dp else 18.dp,
                                                vertical = 10.dp
                                            )
                                            .testTag(tab.testTag),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.title,
                                            tint = if (selected) TextPrimary else TextMuted,
                                            modifier = Modifier.size(if (isCompactWindow) 20.dp else 22.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
