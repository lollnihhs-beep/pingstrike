package com.example.model

enum class ShizukuState {
    NOT_INSTALLED,
    STOPPED,
    PERMISSION_NEEDED,
    CONNECTED,
    SIMULATED
}

enum class PingQuality(val label: String, val colorHex: Long) {
    EXCELLENT("Ultra Low", 0xFF34D399), // <= 35ms
    GOOD("Good", 0xFFD6A8DA),          // 36 - 65ms
    FAIR("Moderate", 0xFFF59E0B),       // 66 - 105ms
    POOR("High Ping", 0xFFF05246)       // > 105ms
}

data class PingServer(
    val id: String,
    val name: String,
    val region: String,
    val host: String,
    val category: String,
    val currentPingMs: Int = -1,
    val jitterMs: Int = 0,
    val packetLossPct: Int = 0,
    val isTesting: Boolean = false
) {
    val quality: PingQuality
        get() = when {
            currentPingMs in 1..35 -> PingQuality.EXCELLENT
            currentPingMs in 36..65 -> PingQuality.GOOD
            currentPingMs in 66..105 -> PingQuality.FAIR
            else -> PingQuality.POOR
        }
}

data class DnsBenchmarkItem(
    val id: String,
    val name: String,
    val hostname: String,
    val description: String,
    val latencyMs: Int = -1,
    val isSelected: Boolean = false,
    val isTesting: Boolean = false
)

data class GameApp(
    val packageName: String,
    val name: String,
    val isInstalled: Boolean = true,
    val defaultFps: Int = 60,
    val targetFps: Int = 120,
    val isGameManagerSupported: Boolean = true
)

data class BackgroundProcessItem(
    val packageName: String,
    val appName: String,
    val category: String,
    val estimatedRamMb: Int,
    val standbyBucket: String = "working_set",
    val isFrozen: Boolean = false,
    val isInstalledOnDevice: Boolean = false
)

data class OptimizationToggles(
    val disableWifiScanSpikes: Boolean = true,
    val wifiLowLatencyMode: Boolean = true,
    val disableBleScanSpikes: Boolean = true,
    val mobileDataAlwaysOn: Boolean = true,
    val tcpBufferPacing: Boolean = true,
    val aggressiveStandbyBuckets: Boolean = true,
    val forceStopBackgroundApps: Boolean = true,
    val gameModePerformance: Boolean = true,
    val restrictBackgroundData: Boolean = true
)

data class NetworkDetails(
    val isWifi: Boolean = true,
    val interfaceName: String = "wlan0",
    val ipAddress: String = "—",
    val linkSpeedMbps: Int = 0,
    val frequencyMhz: Int = 0,
    val rssiDbm: Int = 0,
    val dnsServer: String = "Automatic",
    val gateway: String = "—"
)

data class DeviceTelemetry(
    val deviceModel: String = "",
    val androidVersion: String = "",
    val securityPatch: String = "",
    val kernelVersion: String = "",
    val abi: String = ""
)

data class OptimizationResult(
    val appliedCount: Int,
    val totalCount: Int,
    val summaryLines: List<String>,
    val isSimulated: Boolean
)

data class CommandLogEntry(
    val id: String,
    val timestamp: String,
    val command: String,
    val output: String,
    val exitCode: Int,
    val isSuccess: Boolean,
    val isSimulated: Boolean
)
