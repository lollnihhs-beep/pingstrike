package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.BackgroundProcessItem
import com.example.model.CommandLogEntry
import com.example.model.DeviceTelemetry
import com.example.model.DnsBenchmarkItem
import com.example.model.GameApp
import com.example.model.NetworkDetails
import com.example.model.OptimizationResult
import com.example.model.OptimizationToggles
import com.example.model.PingServer
import com.example.model.ShizukuState
import com.example.service.NetworkOptimizerService
import com.example.service.PingProbeService
import com.example.shizuku.ShizukuManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class PingBoosterViewModel(application: Application) : AndroidViewModel(application) {

    val shizukuManager = ShizukuManager(application)
    val optimizerService = NetworkOptimizerService(application, shizukuManager)
    val probeService = PingProbeService(application)

    val shizukuState: StateFlow<ShizukuState> = shizukuManager.shizukuState
    val commandLogs: StateFlow<List<CommandLogEntry>> = shizukuManager.commandLogs

    private val _isBoosting = MutableStateFlow(false)
    val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

    private val _isStrikeModeActive = MutableStateFlow(false)
    val isStrikeModeActive: StateFlow<Boolean> = _isStrikeModeActive.asStateFlow()

    private val _boostStatusMessage = MutableStateFlow("")
    val boostStatusMessage: StateFlow<String> = _boostStatusMessage.asStateFlow()

    private val _lastOptimizationResult = MutableStateFlow<OptimizationResult?>(null)
    val lastOptimizationResult: StateFlow<OptimizationResult?> = _lastOptimizationResult.asStateFlow()

    private val _toggles = MutableStateFlow(OptimizationToggles())
    val toggles: StateFlow<OptimizationToggles> = _toggles.asStateFlow()

    // Live Ping Meter & History (Real measurements)
    private val _currentPing = MutableStateFlow(0)
    val currentPing: StateFlow<Int> = _currentPing.asStateFlow()

    private val _minPing = MutableStateFlow(0)
    val minPing: StateFlow<Int> = _minPing.asStateFlow()

    private val _maxPing = MutableStateFlow(0)
    val maxPing: StateFlow<Int> = _maxPing.asStateFlow()

    private val _jitter = MutableStateFlow(0)
    val jitter: StateFlow<Int> = _jitter.asStateFlow()

    private val _packetLoss = MutableStateFlow(0f)
    val packetLoss: StateFlow<Float> = _packetLoss.asStateFlow()

    private val _baselinePing = MutableStateFlow<Int?>(null)
    val baselinePing: StateFlow<Int?> = _baselinePing.asStateFlow()

    private val _pingHistory = MutableStateFlow<List<Int>>(emptyList())
    val pingHistory: StateFlow<List<Int>> = _pingHistory.asStateFlow()

    private val _showShizukuRequiredDialog = MutableStateFlow(false)
    val showShizukuRequiredDialog: StateFlow<Boolean> = _showShizukuRequiredDialog.asStateFlow()

    private val defaultGames = listOf(
        GameApp("com.roblox.client", "Roblox", isInstalled = false, defaultFps = 60, targetFps = 120),
        GameApp("com.tencent.ig", "PUBG Mobile", isInstalled = false, defaultFps = 60, targetFps = 120),
        GameApp("com.activision.callofduty.shooter", "Call of Duty: Mobile", isInstalled = false, defaultFps = 60, targetFps = 120),
        GameApp("com.riotgames.league.wildrift", "Wild Rift", isInstalled = false, defaultFps = 60, targetFps = 120),
        GameApp("com.miHoYo.GenshinImpact", "Genshin Impact", isInstalled = false, defaultFps = 60, targetFps = 60),
        GameApp("com.mobile.legends", "Mobile Legends", isInstalled = false, defaultFps = 60, targetFps = 120),
        GameApp("com.dts.freefireth", "Free Fire MAX", isInstalled = false, defaultFps = 60, targetFps = 90)
    )

    private val _installedGames = MutableStateFlow<List<GameApp>>(defaultGames)
    val installedGames: StateFlow<List<GameApp>> = _installedGames.asStateFlow()

    private val _selectedGame = MutableStateFlow(defaultGames[0])
    val selectedGame: StateFlow<GameApp> = _selectedGame.asStateFlow()

    private val _gamingServers = MutableStateFlow<List<PingServer>>(
        listOf(
            PingServer("edge_cf", "Cloudflare Anycast", "Global Edge", "1.1.1.1", "Edge"),
            PingServer("edge_gg", "Google Edge", "Global Edge", "8.8.8.8", "Edge"),
            PingServer("riot_na", "Riot NA East", "Chicago, US", "104.160.131.3", "Esports Game"),
            PingServer("riot_eu", "Riot EU West", "Frankfurt, DE", "104.160.141.3", "Esports Game"),
            PingServer("valve_us", "Valve Steam US", "Seattle, US", "162.254.192.1", "Esports Game"),
            PingServer("valve_sea", "Valve Steam Asia", "Singapore", "103.28.54.1", "Esports Game"),
            PingServer("aws_useast", "AWS US-East", "Virginia, US", "ec2.us-east-1.amazonaws.com", "Cloud AWS"),
            PingServer("aws_jp", "AWS Asia East", "Tokyo, JP", "ec2.ap-northeast-1.amazonaws.com", "Cloud AWS")
        )
    )
    val gamingServers: StateFlow<List<PingServer>> = _gamingServers.asStateFlow()

    private val _dnsProviders = MutableStateFlow<List<DnsBenchmarkItem>>(
        listOf(
            DnsBenchmarkItem("cf", "Cloudflare Gaming (1.1.1.1)", "one.one.one.one", "Fastest global anycast DNS for UDP packets", isSelected = true),
            DnsBenchmarkItem("google", "Google Public DNS", "dns.google", "High availability global anycast routing"),
            DnsBenchmarkItem("nextdns", "NextDNS Gaming", "dns.nextdns.io", "Zero-telemetry low-latency edge routing"),
            DnsBenchmarkItem("adguard", "AdGuard Anti-Ad DNS", "dns.adguard-dns.com", "Blocks ad & tracker queries during matches"),
            DnsBenchmarkItem("quad9", "Quad9 Secure", "dns.quad9.net", "Threat-filtering anycast DNS cluster"),
            DnsBenchmarkItem("opp", "System Default (Automatic)", "opportunistic", "Standard carrier or router DNS")
        )
    )
    val dnsProviders: StateFlow<List<DnsBenchmarkItem>> = _dnsProviders.asStateFlow()

    private val fallbackBackgroundApps = listOf(
        BackgroundProcessItem("com.instagram.android", "Instagram", "Social", 284),
        BackgroundProcessItem("com.facebook.katana", "Facebook", "Social", 390),
        BackgroundProcessItem("com.zhiliaoapp.musically", "TikTok", "Media", 450),
        BackgroundProcessItem("com.google.android.youtube", "YouTube", "Media", 210),
        BackgroundProcessItem("com.spotify.music", "Spotify", "Media", 175),
        BackgroundProcessItem("com.snapchat.android", "Snapchat", "Social", 240)
    )

    private val _backgroundApps = MutableStateFlow<List<BackgroundProcessItem>>(fallbackBackgroundApps)
    val backgroundApps: StateFlow<List<BackgroundProcessItem>> = _backgroundApps.asStateFlow()

    private val _networkDetails = MutableStateFlow(NetworkDetails())
    val networkDetails: StateFlow<NetworkDetails> = _networkDetails.asStateFlow()

    private val _deviceTelemetry = MutableStateFlow(DeviceTelemetry())
    val deviceTelemetry: StateFlow<DeviceTelemetry> = _deviceTelemetry.asStateFlow()

    private var pingMonitorJob: Job? = null
    private var totalProbes = 0
    private var lostProbes = 0

    init {
        _deviceTelemetry.value = probeService.getDeviceTelemetry()
        detectInstalledApps()
        refreshNetworkDetails()
        startLivePingMonitor()
        benchmarkServers()
        benchmarkDns()
    }

    fun dismissShizukuRequiredDialog() {
        _showShizukuRequiredDialog.value = false
    }

    fun selectGame(game: GameApp) {
        _selectedGame.value = game
        vibrateClick()
    }

    fun selectDns(dns: DnsBenchmarkItem) {
        val updated = _dnsProviders.value.map {
            it.copy(isSelected = it.id == dns.id)
        }
        _dnsProviders.value = updated
        vibrateClick()
        viewModelScope.launch {
            val ok = optimizerService.applyPrivateDns(dns.hostname)
            if (ok) {
                refreshNetworkDetails()
                _boostStatusMessage.value = "Private DNS switched to ${dns.name}"
            } else {
                _boostStatusMessage.value = "Authorize Shizuku to apply Private DNS."
            }
        }
    }

    fun updateToggle(update: OptimizationToggles.() -> OptimizationToggles) {
        _toggles.value = _toggles.value.update()
        vibrateClick()
    }

    fun toggleBackgroundAppFreeze(pkg: String) {
        val current = _backgroundApps.value.toMutableList()
        val index = current.indexOfFirst { it.packageName == pkg }
        if (index != -1) {
            val item = current[index]
            val newFrozen = !item.isFrozen
            current[index] = item.copy(
                isFrozen = newFrozen,
                standbyBucket = if (newFrozen) "restricted" else "working_set"
            )
            _backgroundApps.value = current
            vibrateClick()

            viewModelScope.launch {
                if (newFrozen) {
                    optimizerService.freezeApp(pkg)
                } else {
                    optimizerService.unfreezeApp(pkg)
                }
            }
        }
    }

    fun freezeAllBackgroundApps() {
        if (shizukuState.value != ShizukuState.CONNECTED && shizukuState.value != ShizukuState.SIMULATED) {
            _showShizukuRequiredDialog.value = true
            return
        }
        val current = _backgroundApps.value.map {
            it.copy(isFrozen = true, standbyBucket = "restricted")
        }
        _backgroundApps.value = current
        vibrateClick()

        viewModelScope.launch {
            for (app in current) {
                optimizerService.freezeApp(app.packageName)
            }
        }
    }

    fun unfreezeAllBackgroundApps() {
        val current = _backgroundApps.value.map {
            it.copy(isFrozen = false, standbyBucket = "working_set")
        }
        _backgroundApps.value = current
        vibrateClick()

        viewModelScope.launch {
            for (app in current) {
                optimizerService.unfreezeApp(app.packageName)
            }
        }
    }

    fun toggleStrikeMode() {
        if (_isStrikeModeActive.value) {
            revertStrikeMode()
        } else {
            activateStrikeMode()
        }
    }

    fun activateStrikeMode() {
        val currentShizuku = shizukuManager.checkStatus()
        if (currentShizuku != ShizukuState.CONNECTED && currentShizuku != ShizukuState.SIMULATED) {
            _showShizukuRequiredDialog.value = true
            _boostStatusMessage.value = "Shizuku connection required to apply system tweaks."
            return
        }

        viewModelScope.launch {
            _isBoosting.value = true
            vibrateHeavy()
            if (_currentPing.value > 0) {
                _baselinePing.value = _currentPing.value
            }

            _boostStatusMessage.value = "Applying Wi-Fi low-latency & TCP optimizations..."
            val selectedDns = _dnsProviders.value.firstOrNull { it.isSelected }?.hostname ?: "one.one.one.one"
            val appsToFreeze = _backgroundApps.value.map { it.packageName }

            val result = optimizerService.applyStrikeMode(
                game = _selectedGame.value,
                toggles = _toggles.value,
                selectedDnsHost = selectedDns,
                frozenApps = appsToFreeze
            )

            _lastOptimizationResult.value = result
            if (_toggles.value.aggressiveStandbyBuckets) {
                _backgroundApps.value = _backgroundApps.value.map { it.copy(isFrozen = true, standbyBucket = "restricted") }
            }

            refreshNetworkDetails()
            _isBoosting.value = false
            _isStrikeModeActive.value = result.appliedCount > 0

            val modeNote = if (result.isSimulated) " (Simulated)" else ""
            _boostStatusMessage.value =
                "Applied ${result.appliedCount}/${result.totalCount} system tweaks$modeNote"
            vibrateSuccess()
        }
    }

    fun revertStrikeMode() {
        viewModelScope.launch {
            _isBoosting.value = true
            vibrateClick()
            _boostStatusMessage.value = "Restoring default system network & standby rules..."

            val frozenApps = _backgroundApps.value.map { it.packageName }
            val result = optimizerService.restoreDefaults(_selectedGame.value, frozenApps)
            _lastOptimizationResult.value = result
            _backgroundApps.value = _backgroundApps.value.map { it.copy(isFrozen = false, standbyBucket = "working_set") }

            refreshNetworkDetails()
            _isBoosting.value = false
            _isStrikeModeActive.value = false
            _baselinePing.value = null
            _boostStatusMessage.value = "Restored ${result.appliedCount}/${result.totalCount} default settings."
            vibrateClick()
        }
    }

    fun benchmarkServers() {
        viewModelScope.launch {
            _gamingServers.value = _gamingServers.value.map { it.copy(isTesting = true) }
            val results = probeService.benchmarkServers(_gamingServers.value)
            _gamingServers.value = results
        }
    }

    fun benchmarkDns() {
        viewModelScope.launch {
            _dnsProviders.value = _dnsProviders.value.map { it.copy(isTesting = true) }
            val results = probeService.benchmarkDnsProviders(_dnsProviders.value)
            _dnsProviders.value = results
        }
    }

    fun refreshNetworkDetails() {
        _networkDetails.value = probeService.getNetworkDetails()
    }

    fun executeCustomCommand(cmd: String) {
        viewModelScope.launch {
            shizukuManager.executeCommand(cmd)
            vibrateClick()
        }
    }

    private fun startLivePingMonitor() {
        pingMonitorJob?.cancel()
        pingMonitorJob = viewModelScope.launch {
            val primaryHost = "1.1.1.1"
            var lastPing = 0

            while (isActive) {
                val ping = probeService.probeHost(primaryHost)
                totalProbes++
                if (ping > 0) {
                    val currentJitter = if (lastPing > 0) abs(ping - lastPing) else 0
                    lastPing = ping

                    _currentPing.value = ping
                    _jitter.value = currentJitter
                    _minPing.value = if (_minPing.value == 0) ping else minOf(_minPing.value, ping)
                    _maxPing.value = maxOf(_maxPing.value, ping)

                    val history = _pingHistory.value.toMutableList()
                    history.add(ping)
                    if (history.size > 24) {
                        history.removeAt(0)
                    }
                    _pingHistory.value = history
                } else {
                    lostProbes++
                }

                if (totalProbes > 0) {
                    _packetLoss.value = (lostProbes.toFloat() / totalProbes.toFloat()) * 100f
                }

                delay(2000)
            }
        }
    }

    private fun detectInstalledApps() {
        viewModelScope.launch {
            try {
                val pm = getApplication<Application>().packageManager
                val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                val detectedGames = mutableListOf<GameApp>()
                val detectedBgApps = mutableListOf<BackgroundProcessItem>()

                val excludedPkgs = setOf(
                    getApplication<Application>().packageName,
                    "moe.shizuku.privileged.api",
                    "com.android.vending"
                )

                val knownGamePkgs = defaultGames.associateBy { it.packageName }

                for (app in installed) {
                    val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    if (isSystem || app.packageName in excludedPkgs) continue

                    val label = pm.getApplicationLabel(app).toString()
                    val isGame = (app.category == ApplicationInfo.CATEGORY_GAME) ||
                            knownGamePkgs.containsKey(app.packageName) ||
                            label.contains("game", ignoreCase = true)

                    if (isGame) {
                        val fps = knownGamePkgs[app.packageName]?.targetFps ?: 120
                        detectedGames.add(
                            GameApp(
                                packageName = app.packageName,
                                name = label,
                                isInstalled = true,
                                defaultFps = 60,
                                targetFps = fps
                            )
                        )
                    } else {
                        val cat = when (app.category) {
                            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
                            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Media"
                            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
                            else -> "User App"
                        }
                        detectedBgApps.add(
                            BackgroundProcessItem(
                                packageName = app.packageName,
                                appName = label,
                                category = cat,
                                estimatedRamMb = (120..360).random(),
                                isInstalledOnDevice = true
                            )
                        )
                    }
                }

                if (detectedGames.isNotEmpty()) {
                    val combinedGames = (detectedGames + defaultGames).distinctBy { it.packageName }
                    _installedGames.value = combinedGames
                    _selectedGame.value = detectedGames.first()
                }

                if (detectedBgApps.isNotEmpty()) {
                    val heavyHogs = setOf(
                        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
                        "com.instagram.android", "com.facebook.katana", "com.facebook.orca",
                        "com.google.android.youtube", "com.android.chrome", "com.whatsapp",
                        "org.telegram.messenger", "com.discord", "com.snapchat.android",
                        "com.spotify.music", "com.netflix.mediaclient", "tv.twitch.android.app",
                        "com.twitter.android", "com.reddit.frontpage"
                    )
                    val sorted = detectedBgApps.sortedWith(
                        compareByDescending<BackgroundProcessItem> { it.packageName in heavyHogs }
                            .thenByDescending { it.category == "Social" || it.category == "Media" }
                            .thenBy { it.appName }
                    )
                    _backgroundApps.value = sorted.take(24)
                }
            } catch (e: Exception) {
                // Keep defaults in test / restricted environments
            }
        }
    }

    private fun vibrateClick() {
        try {
            val v = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (ignored: Exception) {}
    }

    private fun vibrateHeavy() {
        try {
            val v = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (ignored: Exception) {}
    }

    private fun vibrateSuccess() {
        try {
            val v = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 25, 70, 35), -1))
        } catch (ignored: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        pingMonitorJob?.cancel()
        shizukuManager.destroy()
    }
}
