package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Plum-Obsidian Material You Dark Palette (inspired by AxManager aesthetic)
val DarkBackground = Color(0xFF110E13)
val DarkSurface = Color(0xFF18141B)
val DarkSurfaceCard = Color(0xFF1F1A23)
val DarkSurfaceVariant = Color(0xFF2A232F)
val DarkBorder = Color(0xFF332B38)
val DividerSubtle = Color(0xFF2D2532)

// Primary Lavender / Orchid Accents
val CyberCyan = Color(0xFFD6A8DA)       // Primary soft orchid-lavender highlight
val CyberCyanDim = Color(0xFF9C72A1)    // Muted lavender section titles
val NavPillActive = Color(0xFF5A3D61)   // Floating nav pill active container
val NavBarSurface = Color(0xFF231D27)   // Floating nav bar container

// Semantic Status Colors
val NeonGreen = Color(0xFF34D399)       // Connected / Ultra Low Ping
val NeonAmber = Color(0xFFF59E0B)       // Permission Needed / Moderate
val NeonRed = Color(0xFFF05246)         // Stopped / Error
val NeonPurple = Color(0xFFB388FF)      // Simulated Mode

// Hero Card Semantic Containers
val HeroStoppedBg = Color(0xFF8A2E28)
val HeroActiveBg = Color(0xFF15573F)
val HeroReadyBg = Color(0xFF322340)
val HeroWarningBg = Color(0xFF734918)
val HeroSimBg = Color(0xFF3A255E)

val TextPrimary = Color(0xFFF5EFF7)
val TextSecondary = Color(0xFFB0A6B4)
val TextMuted = Color(0xFF786E7C)
