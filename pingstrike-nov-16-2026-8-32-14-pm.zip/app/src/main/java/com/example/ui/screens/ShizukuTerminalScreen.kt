package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommandLogEntry
import com.example.model.ShizukuState
import com.example.ui.components.ShizukuSetupGuideDialog
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanDim
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PingBoosterViewModel

@Composable
fun ShizukuTerminalScreen(
    viewModel: PingBoosterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val shizukuState by viewModel.shizukuState.collectAsState()
    val detailedMsg by viewModel.shizukuManager.detailedStatusMessage.collectAsState()
    val commandLogs by viewModel.commandLogs.collectAsState()

    var customCommand by remember { mutableStateOf("") }
    var showGuide by remember { mutableStateOf(false) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("shizuku_terminal_screen"),
        contentAlignment = Alignment.TopCenter
    ) {
        val isCompactWindow = maxWidth < 360.dp
        val horizontalPad = if (isCompactWindow) 12.dp else 18.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .statusBarsPadding()
                .padding(horizontal = horizontalPad)
                .padding(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(if (isCompactWindow) 10.dp else 14.dp)
        ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = "Shizuku Shell",
                    color = TextPrimary,
                    fontSize = if (isCompactWindow) 20.sp else 24.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Privileged command logs & diagnostics",
                    color = TextSecondary,
                    fontSize = if (isCompactWindow) 11.sp else 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(
                    onClick = { showGuide = true },
                    modifier = Modifier
                        .size(36.dp)
                        .background(DarkSurfaceCard, CircleShape)
                        .border(1.dp, DarkBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = "Shizuku Guide",
                        tint = CyberCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.shizukuManager.clearLogs() },
                    modifier = Modifier
                        .size(36.dp)
                        .background(DarkSurfaceCard, CircleShape)
                        .border(1.dp, DarkBorder, CircleShape)
                        .testTag("clear_logs_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ClearAll,
                        contentDescription = "Clear logs",
                        tint = TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Binder status card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
                .border(
                    1.dp,
                    if (shizukuState == ShizukuState.CONNECTED) NeonGreen.copy(alpha = 0.5f) else DarkBorder,
                    RoundedCornerShape(16.dp)
                )
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                val iconTint = when (shizukuState) {
                    ShizukuState.CONNECTED -> NeonGreen
                    ShizukuState.SIMULATED -> NeonPurple
                    ShizukuState.PERMISSION_NEEDED -> NeonAmber
                    else -> NeonRed
                }
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(iconTint.copy(alpha = 0.16f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(19.dp)
                    )
                }

                Column {
                    Text(
                        text = when (shizukuState) {
                            ShizukuState.CONNECTED -> "Binder Active"
                            ShizukuState.SIMULATED -> "Simulation Mode"
                            ShizukuState.PERMISSION_NEEDED -> "Authorization Required"
                            ShizukuState.STOPPED -> "Service Stopped"
                            ShizukuState.NOT_INSTALLED -> "Not Installed"
                        },
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = detailedMsg,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 2
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(
                    onClick = { viewModel.shizukuManager.checkStatus() },
                    modifier = Modifier
                        .background(DarkSurfaceVariant, CircleShape)
                        .size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Shizuku",
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }

                OutlinedButton(
                    onClick = {
                        viewModel.shizukuManager.setSimulationMode(shizukuState != ShizukuState.SIMULATED)
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (shizukuState == ShizukuState.SIMULATED) NeonPurple else CyberCyan
                    ),
                    modifier = Modifier.testTag("toggle_simulation_button")
                ) {
                    Text(
                        text = if (shizukuState == ShizukuState.SIMULATED) "Real" else "Sim",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Quick Presets
        Text(
            text = "Quick Diagnostics",
            color = CyberCyanDim,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PresetButton(
                title = "Check UID",
                onClick = { viewModel.executeCustomCommand("id") },
                modifier = Modifier.weight(1f)
            )
            PresetButton(
                title = "Wi-Fi Scan",
                onClick = { viewModel.executeCustomCommand("settings get global wifi_scan_always_enabled") },
                modifier = Modifier.weight(1f)
            )
            PresetButton(
                title = "Ping 1.1.1.1",
                onClick = { viewModel.executeCustomCommand("ping -c 2 1.1.1.1") },
                modifier = Modifier.weight(1f)
            )
        }

        // Command Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = customCommand,
                onValueChange = { customCommand = it },
                placeholder = {
                    Text(
                        "settings get global private_dns_mode",
                        color = TextMuted,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("custom_command_input"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            Button(
                onClick = {
                    if (customCommand.isNotBlank()) {
                        viewModel.executeCustomCommand(customCommand)
                        customCommand = ""
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyberCyan,
                    contentColor = Color.Black
                ),
                modifier = Modifier
                    .size(50.dp)
                    .testTag("run_command_button"),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Execute Command",
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Console Output (${commandLogs.size})",
                color = CyberCyanDim,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (commandLogs.isNotEmpty()) {
                Text(
                    text = "Copy All",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable {
                        val text = commandLogs.joinToString("\n\n") {
                            "[${it.timestamp}] $ ${it.command}\n${it.output}"
                        }
                        copyToClipboard(context, text)
                    }
                )
            }
        }

        if (commandLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(34.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No shell commands executed yet",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Activate Strike Mode or run a diagnostic check above",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(commandLogs, key = { it.id }) { log ->
                    TerminalLogCard(log = log)
                }
            }
        }
        }
    }

    if (showGuide) {
        ShizukuSetupGuideDialog(
            isSimulationMode = shizukuState == ShizukuState.SIMULATED,
            onToggleSimulation = { viewModel.shizukuManager.setSimulationMode(it) },
            onDismiss = { showGuide = false }
        )
    }
}

@Composable
private fun PresetButton(
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = CyberCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TerminalLogCard(log: CommandLogEntry) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceVariant.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
            .border(
                1.dp,
                if (log.isSuccess) DarkBorder else NeonRed.copy(alpha = 0.5f),
                RoundedCornerShape(10.dp)
            )
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = log.timestamp,
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (log.isSimulated) {
                    Text(
                        text = "SIM",
                        color = NeonPurple,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = if (log.isSuccess) "EXIT 0" else "EXIT ${log.exitCode}",
                color = if (log.isSuccess) NeonGreen else NeonRed,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "$ ${log.command}",
            color = CyberCyan,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(3.dp))

        Text(
            text = log.output,
            color = if (log.isSuccess) TextPrimary else NeonRed,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 14.sp
        )
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Terminal Log", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Log copied to clipboard", Toast.LENGTH_SHORT).show()
}
