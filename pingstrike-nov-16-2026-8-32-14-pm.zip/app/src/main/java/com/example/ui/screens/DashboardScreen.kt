package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ShizukuState
import com.example.ui.components.GameSelectorSheet
import com.example.ui.components.LivePingGraph
import com.example.ui.components.ShizukuSetupGuideDialog
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanDim
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DividerSubtle
import com.example.ui.theme.HeroActiveBg
import com.example.ui.theme.HeroReadyBg
import com.example.ui.theme.HeroSimBg
import com.example.ui.theme.HeroStoppedBg
import com.example.ui.theme.HeroWarningBg
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PingBoosterViewModel

@Composable
fun DashboardScreen(
    viewModel: PingBoosterViewModel,
    onNavigateToNetwork: () -> Unit,
    onNavigateToTasks: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shizukuState by viewModel.shizukuState.collectAsState()
    val detailedStatus by viewModel.shizukuManager.detailedStatusMessage.collectAsState()
    val shizukuUid by viewModel.shizukuManager.shizukuUid.collectAsState()
    val isBoosting by viewModel.isBoosting.collectAsState()
    val isStrikeModeActive by viewModel.isStrikeModeActive.collectAsState()
    val boostStatusMessage by viewModel.boostStatusMessage.collectAsState()
    val lastResult by viewModel.lastOptimizationResult.collectAsState()
    val currentPing by viewModel.currentPing.collectAsState()
    val baselinePing by viewModel.baselinePing.collectAsState()
    val jitter by viewModel.jitter.collectAsState()
    val packetLoss by viewModel.packetLoss.collectAsState()
    val pingHistory by viewModel.pingHistory.collectAsState()
    val selectedGame by viewModel.selectedGame.collectAsState()
    val installedGames by viewModel.installedGames.collectAsState()
    val networkDetails by viewModel.networkDetails.collectAsState()
    val deviceTelemetry by viewModel.deviceTelemetry.collectAsState()
    val showShizukuPrompt by viewModel.showShizukuRequiredDialog.collectAsState()

    var showGameSelector by remember { mutableStateOf(false) }
    var showGuideDialog by remember { mutableStateOf(false) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen")
    ) {
        val isCompactWindow = maxWidth < 360.dp
        val horizontalPad = if (isCompactWindow) 12.dp else 18.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = horizontalPad)
                .padding(top = 12.dp, bottom = 104.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(if (isCompactWindow) 12.dp else 16.dp)
            ) {
                // Minimal Clean App Header (AxManager style, responsive for floating windows)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            text = "PingStrike",
                            color = TextPrimary,
                            fontSize = if (isCompactWindow) 22.sp else 28.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (isCompactWindow) "Shizuku Engine" else "v1.0 • Shizuku Latency Engine",
                            color = TextSecondary,
                            fontSize = if (isCompactWindow) 11.sp else 13.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(DarkSurfaceCard, RoundedCornerShape(20.dp))
                                .border(1.dp, DarkBorder, RoundedCornerShape(20.dp))
                                .padding(
                                    horizontal = if (isCompactWindow) 9.dp else 12.dp,
                                    vertical = 6.dp
                                )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .background(
                                            when {
                                                currentPing <= 0 -> TextMuted
                                                currentPing <= 40 -> NeonGreen
                                                currentPing <= 80 -> NeonAmber
                                                else -> NeonRed
                                            },
                                            CircleShape
                                        )
                                )
                                Text(
                                    text = if (currentPing > 0) "${currentPing} ms" else "— ms",
                                    color = TextPrimary,
                                    fontSize = if (isCompactWindow) 11.sp else 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                viewModel.shizukuManager.checkStatus()
                                viewModel.refreshNetworkDetails()
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .size(38.dp)
                                .background(DarkSurfaceCard, CircleShape)
                                .border(1.dp, DarkBorder, CircleShape)
                                .testTag("refresh_shizuku_status")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh status",
                                tint = CyberCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Hero Status Card (Modeled directly after AxManager's clean hero card)
                HeroStatusCard(
                    shizukuState = shizukuState,
                    isStrikeModeActive = isStrikeModeActive,
                    isBoosting = isBoosting,
                    detailedStatus = detailedStatus,
                    shizukuUid = shizukuUid,
                    selectedGameName = selectedGame.name,
                    currentPing = currentPing,
                    isCompactWindow = isCompactWindow,
                    onPrimaryClick = {
                        when (shizukuState) {
                            ShizukuState.CONNECTED, ShizukuState.SIMULATED -> viewModel.toggleStrikeMode()
                            ShizukuState.PERMISSION_NEEDED -> viewModel.shizukuManager.requestPermission()
                            ShizukuState.STOPPED -> {
                                if (!viewModel.shizukuManager.openShizukuApp()) {
                                    showGuideDialog = true
                                }
                            }
                            ShizukuState.NOT_INSTALLED -> showGuideDialog = true
                        }
                    }
                )

                // Reconnect helper when Shizuku was started in a floating window while PingStrike was already open
                if (shizukuState == ShizukuState.STOPPED) {
                    ActionStripCard(
                        icon = Icons.Default.Refresh,
                        title = "Reconnect Shizuku Binder",
                        subtitle = "Already started Shizuku? Tap to re-bind service",
                        onClick = { viewModel.shizukuManager.relaunchForBinder() },
                        testTag = "reconnect_binder_button"
                    )
                }

                // Secondary Action Card (Matching "New version..." card in screenshot)
                ActionStripCard(
                    icon = Icons.Default.SportsEsports,
                    title = "Target Game: ${selectedGame.name}",
                    subtitle = "${selectedGame.targetFps} FPS priority • Tap to switch game",
                    onClick = { showGameSelector = true },
                    testTag = "target_game_card"
                )

        // Strike Mode Toggle & Applied Tweaks Summary Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(18.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
                .padding(16.dp)
                .testTag("strike_mode_button"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (isStrikeModeActive) NeonGreen.copy(alpha = 0.16f) else DarkSurfaceVariant,
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isBoosting) {
                            CircularProgressIndicator(
                                color = CyberCyan,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = if (isStrikeModeActive) NeonGreen else CyberCyan,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = if (isStrikeModeActive) "Strike Mode Active" else "Strike Mode",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isStrikeModeActive) {
                                "Wi-Fi low-latency, Private DNS & app throttling on"
                            } else {
                                "Optimize Wi-Fi, DNS, TCP & freeze background hogs"
                            },
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Switch(
                    checked = isStrikeModeActive,
                    onCheckedChange = {
                        if (!isBoosting) viewModel.toggleStrikeMode()
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = NeonGreen,
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = DarkSurfaceVariant
                    )
                )
            }

            AnimatedVisibility(visible = boostStatusMessage.isNotEmpty() || lastResult != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceVariant.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (boostStatusMessage.isNotEmpty()) {
                        Text(
                            text = boostStatusMessage,
                            color = if (isStrikeModeActive) NeonGreen else CyberCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (baselinePing != null && currentPing > 0 && isStrikeModeActive) {
                        val delta = baselinePing!! - currentPing
                        val deltaText = when {
                            delta > 0 -> "-${delta} ms lower than baseline (${baselinePing} ms)"
                            delta == 0 -> "Same as baseline (${baselinePing} ms)"
                            else -> "+${-delta} ms vs baseline (${baselinePing} ms)"
                        }
                        Text(
                            text = "Measured Ping: $deltaText",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    lastResult?.let { result ->
                        if (result.summaryLines.isNotEmpty()) {
                            Text(
                                text = result.summaryLines.take(4).joinToString("  •  "),
                                color = TextMuted,
                                fontSize = 10.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Section Header: Device & Network Information (AxManager style)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Network & Device Information",
                color = CyberCyanDim,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = "Tune Network →",
                color = CyberCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onNavigateToNetwork() }
            )
        }

        // Clean 2-Column Hairline Grid Card (Exact visual style of AxManager's "Device Information")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(18.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
                .padding(vertical = 4.dp)
        ) {
            TelemetryGridRow(
                leftLabel = "Live Ping",
                leftValue = if (currentPing > 0) "$currentPing ms" else "Measuring...",
                rightLabel = "Jitter & Loss",
                rightValue = "±${jitter} ms • ${packetLoss.toInt()}% loss",
                isCompactWindow = isCompactWindow
            )
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            TelemetryGridRow(
                leftLabel = "Interface",
                leftValue = if (networkDetails.isWifi) {
                    val band = if (networkDetails.frequencyMhz >= 5000) "5GHz" else "2.4GHz"
                    val spd = if (networkDetails.linkSpeedMbps > 0) " • ${networkDetails.linkSpeedMbps}Mbps" else ""
                    "${networkDetails.interfaceName} ($band$spd)"
                } else {
                    "${networkDetails.interfaceName} (Cellular)"
                },
                rightLabel = "Active DNS",
                rightValue = networkDetails.dnsServer,
                isCompactWindow = isCompactWindow
            )
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            TelemetryGridRow(
                leftLabel = "Device",
                leftValue = deviceTelemetry.deviceModel.ifBlank { "Android Device" },
                rightLabel = "Android Version",
                rightValue = deviceTelemetry.androidVersion.ifBlank { "—" },
                isCompactWindow = isCompactWindow
            )
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            TelemetryGridRow(
                leftLabel = "Kernel",
                leftValue = deviceTelemetry.kernelVersion.ifBlank { "—" },
                rightLabel = "ABI Supported",
                rightValue = deviceTelemetry.abi.ifBlank { "arm64-v8a" },
                isCompactWindow = isCompactWindow
            )
        }

        // Section Header: Latency Stability
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Latency Stability",
                color = CyberCyanDim,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = "Background Tasks →",
                color = CyberCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onNavigateToTasks() }
            )
        }

        LivePingGraph(
            history = pingHistory,
            isStrikeActive = isStrikeModeActive
        )

        // Secondary Diagnostics Card
        ActionStripCard(
            icon = Icons.Outlined.Tune,
            title = "Shizuku Setup & Diagnostics",
            subtitle = "View wireless ADB steps or toggle Simulation Mode",
            onClick = { showGuideDialog = true },
            testTag = "setup_guide_button"
        )
            }
        }
    }

    if (showGameSelector) {
        GameSelectorSheet(
            games = installedGames,
            selectedGame = selectedGame,
            onSelectGame = { viewModel.selectGame(it) },
            onDismiss = { showGameSelector = false }
        )
    }

    if (showGuideDialog) {
        ShizukuSetupGuideDialog(
            isSimulationMode = shizukuState == ShizukuState.SIMULATED,
            onToggleSimulation = { viewModel.shizukuManager.setSimulationMode(it) },
            onDismiss = { showGuideDialog = false }
        )
    }

    if (showShizukuPrompt) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissShizukuRequiredDialog() },
            containerColor = DarkSurfaceCard,
            title = {
                Text(
                    text = "Shizuku Not Connected",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Real system network tweaks require an active Shizuku binder. Make sure Shizuku is running and PingStrike is authorized, or enable Simulation Mode to preview the workflow.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.dismissShizukuRequiredDialog()
                        if (shizukuState == ShizukuState.PERMISSION_NEEDED) {
                            viewModel.shizukuManager.requestPermission()
                        } else {
                            showGuideDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black)
                ) {
                    Text(
                        text = if (shizukuState == ShizukuState.PERMISSION_NEEDED) "Authorize" else "Setup Guide",
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        viewModel.dismissShizukuRequiredDialog()
                        viewModel.shizukuManager.setSimulationMode(true)
                    }
                ) {
                    Text("Use Simulation", color = NeonPurple)
                }
            }
        )
    }
}

@Composable
private fun HeroStatusCard(
    shizukuState: ShizukuState,
    isStrikeModeActive: Boolean,
    isBoosting: Boolean,
    detailedStatus: String,
    shizukuUid: Int,
    selectedGameName: String,
    currentPing: Int,
    isCompactWindow: Boolean,
    onPrimaryClick: () -> Unit
) {
    val (bgColor, badgeColor, headline, badgeText, subtitle, watermarkIcon) = when (shizukuState) {
        ShizukuState.CONNECTED -> if (isStrikeModeActive) {
            HeroStyle(
                bgColor = HeroActiveBg,
                badgeColor = NeonGreen,
                headline = "Strike Mode Active",
                badgeText = "Optimized",
                subtitle = "System network & background throttling active",
                watermarkIcon = Icons.Default.Check
            )
        } else {
            HeroStyle(
                bgColor = HeroReadyBg,
                badgeColor = CyberCyan,
                headline = "Shizuku Connected",
                badgeText = "Ready",
                subtitle = "Tap to activate low-latency gaming tweaks",
                watermarkIcon = Icons.Default.Bolt
            )
        }
        ShizukuState.PERMISSION_NEEDED -> HeroStyle(
            bgColor = HeroWarningBg,
            badgeColor = NeonAmber,
            headline = "Need Authorization",
            badgeText = "Permission",
            subtitle = "Click to grant Shizuku ADB access to PingStrike",
            watermarkIcon = Icons.Default.Security
        )
        ShizukuState.SIMULATED -> HeroStyle(
            bgColor = HeroSimBg,
            badgeColor = NeonPurple,
            headline = if (isStrikeModeActive) "Simulated Boost On" else "Simulation Mode",
            badgeText = "Virtual",
            subtitle = if (isStrikeModeActive) "Tap to restore virtual defaults" else "Tap to test Strike Mode virtually",
            watermarkIcon = Icons.Default.Bolt
        )
        ShizukuState.STOPPED -> HeroStyle(
            bgColor = HeroStoppedBg,
            badgeColor = NeonRed,
            headline = "Need to Activate",
            badgeText = "Stopped",
            subtitle = "Shizuku installed — tap to open Shizuku & start",
            watermarkIcon = Icons.Default.Close
        )
        ShizukuState.NOT_INSTALLED -> HeroStyle(
            bgColor = HeroStoppedBg,
            badgeColor = NeonRed,
            headline = "Shizuku Required",
            badgeText = "Missing",
            subtitle = "Tap for setup instructions or test simulation",
            watermarkIcon = Icons.Default.Close
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(bgColor)
            .clickable(enabled = !isBoosting) { onPrimaryClick() }
            .testTag("shizuku_status_bar")
    ) {
        // Large subtle watermark circle icon clipped at bottom-right (AxManager signature detail)
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 18.dp, y = 20.dp)
                .size(126.dp)
                .border(12.dp, Color.White.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = watermarkIcon,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.14f),
                modifier = Modifier.size(64.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(if (isCompactWindow) 14.dp else 18.dp),
            verticalArrangement = Arrangement.spacedBy(if (isCompactWindow) 10.dp else 14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 6.dp)
                    ) {
                        Text(
                            text = headline,
                            color = Color.White,
                            fontSize = if (isCompactWindow) 17.sp else 21.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )

                        Box(
                            modifier = Modifier
                                .background(badgeColor, RoundedCornerShape(50))
                                .padding(
                                    horizontal = if (isCompactWindow) 8.dp else 10.dp,
                                    vertical = 3.dp
                                )
                        ) {
                            Text(
                                text = badgeText,
                                color = if (badgeColor == NeonRed) Color.White else Color.Black,
                                fontSize = if (isCompactWindow) 10.sp else 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 13.sp
                )
            }

            // Bottom translucent dark info pill inside Hero Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.28f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(15.dp)
                )
                val uidPart = if (shizukuUid >= 0) "UID: $shizukuUid" else detailedStatus
                val pingPart = if (currentPing > 0) "${currentPing}ms" else "Probing"
                Text(
                    text = "$uidPart  |  $selectedGameName  |  $pingPart",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ActionStripCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .padding(14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .background(DarkSurfaceVariant, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = CyberCyan,
                modifier = Modifier.size(22.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun TelemetryGridRow(
    leftLabel: String,
    leftValue: String,
    rightLabel: String,
    rightValue: String,
    isCompactWindow: Boolean = false
) {
    val cellPadH = if (isCompactWindow) 12.dp else 16.dp
    val cellPadV = if (isCompactWindow) 11.dp else 14.dp
    val valueSize = if (isCompactWindow) 13.sp else 14.sp

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = cellPadH, vertical = cellPadV),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = leftLabel,
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = leftValue,
                color = TextPrimary,
                fontSize = valueSize,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        VerticalDivider(
            color = DividerSubtle,
            thickness = 1.dp,
            modifier = Modifier.fillMaxHeight()
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = cellPadH, vertical = cellPadV),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = rightLabel,
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = rightValue,
                color = TextPrimary,
                fontSize = valueSize,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private data class HeroStyle(
    val bgColor: Color,
    val badgeColor: Color,
    val headline: String,
    val badgeText: String,
    val subtitle: String,
    val watermarkIcon: ImageVector
)
