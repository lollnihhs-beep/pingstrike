package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DnsBenchmarkItem
import com.example.model.PingQuality
import com.example.model.PingServer
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanDim
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DividerSubtle
import com.example.ui.theme.NavPillActive
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PingBoosterViewModel

@Composable
fun NetworkOptimizerScreen(
    viewModel: PingBoosterViewModel,
    modifier: Modifier = Modifier
) {
    val toggles by viewModel.toggles.collectAsState()
    val dnsProviders by viewModel.dnsProviders.collectAsState()
    val servers by viewModel.gamingServers.collectAsState()
    val networkDetails by viewModel.networkDetails.collectAsState()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("network_optimizer_screen")
    ) {
        val isCompactWindow = maxWidth < 360.dp
        val horizontalPad = if (isCompactWindow) 12.dp else 18.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = horizontalPad)
                .padding(top = 12.dp, bottom = 104.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(if (isCompactWindow) 12.dp else 16.dp)
            ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = "Network Tuning",
                    color = TextPrimary,
                    fontSize = if (isCompactWindow) 20.sp else 24.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Shizuku system settings & DNS latency probes",
                    color = TextSecondary,
                    fontSize = if (isCompactWindow) 11.sp else 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = { viewModel.refreshNetworkDetails() },
                modifier = Modifier
                    .size(38.dp)
                    .background(DarkSurfaceCard, CircleShape)
                    .border(1.dp, DarkBorder, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh telemetry",
                    tint = CyberCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Hardware Interface Telemetry Grid (AxManager grid card style)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(18.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
        ) {
            Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                TelemetryCell(
                    label = "Interface",
                    value = "${networkDetails.interfaceName} (${if (networkDetails.isWifi) "Wi-Fi" else "Cellular"})",
                    modifier = Modifier.weight(1f)
                )
                VerticalDivider(color = DividerSubtle, thickness = 1.dp, modifier = Modifier.fillMaxHeight())
                TelemetryCell(
                    label = "Link & Signal",
                    value = if (networkDetails.linkSpeedMbps > 0) "${networkDetails.linkSpeedMbps} Mbps • ${networkDetails.rssiDbm}dBm" else "Active",
                    modifier = Modifier.weight(1f)
                )
            }
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                TelemetryCell(
                    label = "IP Address",
                    value = networkDetails.ipAddress,
                    modifier = Modifier.weight(1f)
                )
                VerticalDivider(color = DividerSubtle, thickness = 1.dp, modifier = Modifier.fillMaxHeight())
                TelemetryCell(
                    label = "Private DNS",
                    value = networkDetails.dnsServer,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section 1: System Network Toggles
        Text(
            text = "Shizuku Network Tweaks",
            color = CyberCyanDim,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(18.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
        ) {
            OptimizationToggleRow(
                title = "Block Wi-Fi Scan Spikes",
                description = "Disables background Wi-Fi scanning to prevent periodic 200ms ping spikes",
                icon = Icons.Default.Router,
                isChecked = toggles.disableWifiScanSpikes,
                onCheckedChange = { viewModel.updateToggle { copy(disableWifiScanSpikes = it) } }
            )
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            OptimizationToggleRow(
                title = "Wi-Fi HAL Low-Latency & Hi-Perf",
                description = "Forces Wi-Fi chipset into continuous low-latency burst mode",
                icon = Icons.Default.Speed,
                isChecked = toggles.wifiLowLatencyMode,
                onCheckedChange = { viewModel.updateToggle { copy(wifiLowLatencyMode = it) } }
            )
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            OptimizationToggleRow(
                title = "Disable BLE Combo-Radio Scans",
                description = "Stops Bluetooth LE background probes sharing the Wi-Fi antenna",
                icon = Icons.Default.BluetoothDisabled,
                isChecked = toggles.disableBleScanSpikes,
                onCheckedChange = { viewModel.updateToggle { copy(disableBleScanSpikes = it) } }
            )
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            OptimizationToggleRow(
                title = "Mobile Data Instant Failover",
                description = "Keeps cellular radio standby ready to eliminate handoff drops",
                icon = Icons.Default.SignalCellularAlt,
                isChecked = toggles.mobileDataAlwaysOn,
                onCheckedChange = { viewModel.updateToggle { copy(mobileDataAlwaysOn = it) } }
            )
            HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
            OptimizationToggleRow(
                title = "TCP Initial Window Pacing",
                description = "Tunes global tcp_default_init_rwnd=60 for faster burst handshake",
                icon = Icons.Default.Tune,
                isChecked = toggles.tcpBufferPacing,
                onCheckedChange = { viewModel.updateToggle { copy(tcpBufferPacing = it) } }
            )
        }

        // Section 2: Private Gaming DNS Resolver
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Gaming DNS Resolver",
                color = CyberCyanDim,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f).padding(end = 8.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            OutlinedButton(
                onClick = { viewModel.benchmarkDns() },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                modifier = Modifier.testTag("benchmark_dns_button")
            ) {
                Icon(imageVector = Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Benchmark", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            dnsProviders.forEach { dns ->
                DnsItemCard(
                    item = dns,
                    onSelect = { viewModel.selectDns(dns) }
                )
            }
        }

        // Section 3: Regional Gaming Servers Matrix
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Regional Server Ping",
                color = CyberCyanDim,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )

            IconButton(
                onClick = { viewModel.benchmarkServers() },
                modifier = Modifier
                    .size(34.dp)
                    .background(DarkSurfaceCard, CircleShape)
                    .border(1.dp, DarkBorder, CircleShape)
                    .testTag("refresh_servers_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh servers",
                    tint = CyberCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(18.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
        ) {
            servers.forEachIndexed { idx, server ->
                ServerPingRow(server = server)
                if (idx < servers.lastIndex) {
                    HorizontalDivider(color = DividerSubtle, thickness = 1.dp)
                }
            }
        }
            }
        }
    }
}

@Composable
private fun TelemetryCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(text = label, color = TextSecondary, fontSize = 11.sp)
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun OptimizationToggleRow(
    title: String,
    description: String,
    icon: ImageVector,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!isChecked) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(if (isChecked) NavPillActive.copy(alpha = 0.6f) else DarkSurfaceVariant, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isChecked) CyberCyan else TextMuted,
                modifier = Modifier.size(19.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = description,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 14.sp
            )
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = NeonGreen,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = DarkSurfaceVariant
            )
        )
    }
}

@Composable
private fun DnsItemCard(
    item: DnsBenchmarkItem,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (item.isSelected) NavPillActive.copy(alpha = 0.25f) else DarkSurfaceCard)
            .border(1.dp, if (item.isSelected) CyberCyan else DarkBorder, RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(if (item.isSelected) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceVariant, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Dns,
                    contentDescription = null,
                    tint = if (item.isSelected) CyberCyan else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Text(
                    text = item.name,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = item.description,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (item.isTesting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = CyberCyan,
                    strokeWidth = 2.dp
                )
            } else if (item.latencyMs > 0) {
                val pingColor = if (item.latencyMs < 25) NeonGreen else if (item.latencyMs < 55) CyberCyan else NeonAmber
                Text(
                    text = "${item.latencyMs}ms",
                    color = pingColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            if (item.isSelected) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .background(NeonGreen, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Selected",
                        tint = Color.Black,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ServerPingRow(server: PingServer) {
    val pingColor = when {
        server.currentPingMs <= 0 -> TextMuted
        server.quality == PingQuality.EXCELLENT -> NeonGreen
        server.quality == PingQuality.GOOD -> CyberCyan
        server.quality == PingQuality.FAIR -> NeonAmber
        else -> NeonRed
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(pingColor, CircleShape)
            )
            Column {
                Text(
                    text = server.name,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "${server.region} • ${server.host}",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        if (server.isTesting) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                color = CyberCyan,
                strokeWidth = 2.dp
            )
        } else if (server.currentPingMs > 0) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${server.currentPingMs} ms",
                    color = pingColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "±${server.jitterMs}ms",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        } else {
            Text(
                text = "Unreachable",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}
