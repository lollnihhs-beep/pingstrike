package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DividerSubtle
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LivePingGraph(
    history: List<Int>,
    isStrikeActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    val accentColor = if (isStrikeActive) NeonGreen else CyberCyan

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurfaceCard, RoundedCornerShape(18.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
            .padding(16.dp)
            .testTag("live_ping_graph")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(accentColor, CircleShape)
                )
                Text(
                    text = "Real-Time Latency Waveform",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            val latest = history.lastOrNull()
            Text(
                text = if (latest != null && latest > 0) "$latest ms" else "Probing...",
                color = accentColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        if (history.size < 2) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .padding(top = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Timeline,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Measuring live ICMP / TCP socket response...",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .padding(top = 12.dp)
            ) {
                val w = size.width
                val h = size.height
                val maxPingVal = (history.maxOrNull()?.coerceAtLeast(50) ?: 50).toFloat()
                val minPingVal = (history.minOrNull()?.coerceAtMost(10) ?: 10).toFloat()
                val range = (maxPingVal - minPingVal).coerceAtLeast(10f)

                // Guide line
                val midY = h * 0.5f
                drawLine(
                    color = DividerSubtle,
                    start = Offset(0f, midY),
                    end = Offset(w, midY),
                    strokeWidth = 1.dp.toPx()
                )

                val stepX = w / (history.size - 1)
                val path = Path()
                val fillPath = Path()

                history.forEachIndexed { index, ping ->
                    val x = index * stepX
                    val normalizedY = 1f - ((ping - minPingVal) / range).coerceIn(0f, 1f)
                    val y = normalizedY * (h - 10.dp.toPx()) + 5.dp.toPx()

                    if (index == 0) {
                        path.moveTo(x, y)
                        fillPath.moveTo(x, h)
                        fillPath.lineTo(x, y)
                    } else {
                        val prevX = (index - 1) * stepX
                        val prevNormY = 1f - ((history[index - 1] - minPingVal) / range).coerceIn(0f, 1f)
                        val prevY = prevNormY * (h - 10.dp.toPx()) + 5.dp.toPx()
                        val controlX1 = prevX + (x - prevX) / 2
                        val controlX2 = prevX + (x - prevX) / 2
                        path.cubicTo(controlX1, prevY, controlX2, y, x, y)
                        fillPath.cubicTo(controlX1, prevY, controlX2, y, x, y)
                    }
                }

                fillPath.lineTo(w, h)
                fillPath.close()

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(accentColor.copy(alpha = 0.25f), Color.Transparent),
                        startY = 0f,
                        endY = h
                    )
                )

                drawPath(
                    path = path,
                    color = accentColor,
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )

                val lastY = (1f - ((history.last() - minPingVal) / range).coerceIn(0f, 1f)) * (h - 10.dp.toPx()) + 5.dp.toPx()
                drawCircle(color = accentColor.copy(alpha = 0.35f), radius = 6.dp.toPx(), center = Offset(w, lastY))
                drawCircle(color = Color.White, radius = 3.dp.toPx(), center = Offset(w, lastY))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Min ${history.minOrNull() ?: 0} ms", color = TextMuted, fontSize = 11.sp)
                Text(text = "Peak ${history.maxOrNull() ?: 0} ms", color = TextMuted, fontSize = 11.sp)
            }
        }
    }
}
