package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PingStrikeColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color(0xFF241128),
    primaryContainer = NavPillActive,
    onPrimaryContainer = TextPrimary,
    secondary = CyberCyanDim,
    onSecondary = Color.White,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonGreen,
    onTertiary = Color(0xFF032116),
    tertiaryContainer = HeroActiveBg,
    onTertiaryContainer = NeonGreen,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    error = NeonRed,
    onError = Color.White
)

@Composable
fun PingStrikeTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PingStrikeColorScheme,
        typography = Typography,
        content = content
    )
}
