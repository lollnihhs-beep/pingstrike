package com.example.shizuku

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import com.example.model.CommandLogEntry
import com.example.model.ShizukuState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ShizukuManager(private val context: Context) {

    private val _shizukuState = MutableStateFlow(ShizukuState.STOPPED)
    val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

    private val _commandLogs = MutableStateFlow<List<CommandLogEntry>>(emptyList())
    val commandLogs: StateFlow<List<CommandLogEntry>> = _commandLogs.asStateFlow()

    private val _isSimulatedMode = MutableStateFlow(false)
    val isSimulatedMode: StateFlow<Boolean> = _isSimulatedMode.asStateFlow()

    private val _detailedStatusMessage = MutableStateFlow("Checking Shizuku service...")
    val detailedStatusMessage: StateFlow<String> = _detailedStatusMessage.asStateFlow()

    private val _shizukuUid = MutableStateFlow(-1)
    val shizukuUid: StateFlow<Int> = _shizukuUid.asStateFlow()

    private val _shizukuVersion = MutableStateFlow(-1)
    val shizukuVersion: StateFlow<Int> = _shizukuVersion.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main)
    private var autoCheckJob: Job? = null

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
        if (requestCode == REQUEST_CODE_SHIZUKU) {
            checkStatus()
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        checkStatus()
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionListener)
        } catch (t: Throwable) {
            Log.w("ShizukuManager", "Failed to add Shizuku listeners: ${t.message}")
        }
        checkStatus()
        startAutoCheckLoop()
    }

    private fun startAutoCheckLoop() {
        autoCheckJob?.cancel()
        autoCheckJob = scope.launch {
            while (isActive) {
                delay(2000)
                if (!_isSimulatedMode.value) {
                    checkStatus()
                }
            }
        }
    }

    fun setSimulationMode(enabled: Boolean) {
        _isSimulatedMode.value = enabled
        if (enabled) {
            _shizukuState.value = ShizukuState.SIMULATED
            _shizukuUid.value = 2000
            _shizukuVersion.value = 13
            _detailedStatusMessage.value = "Simulated ADB environment active for testing."
        } else {
            checkStatus()
        }
    }

    fun checkStatus(): ShizukuState {
        if (_isSimulatedMode.value) {
            _shizukuState.value = ShizukuState.SIMULATED
            _detailedStatusMessage.value = "Simulated ADB environment active for testing."
            return ShizukuState.SIMULATED
        }

        val state = try {
            val ping = try {
                Shizuku.pingBinder()
            } catch (t: Throwable) {
                false
            }

            if (ping) {
                val hasPermission = try {
                    if (Shizuku.isPreV11()) {
                        context.checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED
                    } else {
                        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    }
                } catch (t: Throwable) {
                    false
                }

                val uid = try { Shizuku.getUid() } catch (e: Exception) { -1 }
                val ver = try { Shizuku.getVersion() } catch (e: Exception) { -1 }
                _shizukuUid.value = uid
                _shizukuVersion.value = ver

                if (hasPermission) {
                    val modeLabel = if (uid == 0) "Root" else "ADB"
                    _detailedStatusMessage.value = "Running ($modeLabel • UID $uid • v$ver)"
                    ShizukuState.CONNECTED
                } else {
                    _detailedStatusMessage.value = "Service running, tap to authorize PingStrike."
                    ShizukuState.PERMISSION_NEEDED
                }
            } else {
                _shizukuUid.value = -1
                _shizukuVersion.value = -1
                val installed = isShizukuInstalled()
                if (installed) {
                    _detailedStatusMessage.value = "Shizuku is installed, waiting for active binder."
                    ShizukuState.STOPPED
                } else {
                    _detailedStatusMessage.value = "Shizuku not found. Install Shizuku or use Simulation."
                    ShizukuState.NOT_INSTALLED
                }
            }
        } catch (t: Throwable) {
            Log.e("ShizukuManager", "Error checking Shizuku status", t)
            _detailedStatusMessage.value = "Error: ${t.localizedMessage}"
            ShizukuState.STOPPED
        }

        _shizukuState.value = state
        return state
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (!Shizuku.isPreV11()) {
                    Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
                }
            } else {
                openShizukuApp()
            }
        } catch (t: Throwable) {
            Log.e("ShizukuManager", "Failed to request Shizuku permission", t)
            openShizukuApp()
        }
    }

    fun openShizukuApp(): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun relaunchForBinder() {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                context.startActivity(intent)
                android.os.Process.killProcess(android.os.Process.myPid())
            }
        } catch (e: Exception) {
            checkStatus()
        }
    }

    fun isShizukuInstalled(): Boolean {
        try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            return true
        } catch (ignored: Exception) {}

        try {
            val intent = Intent(Intent.ACTION_MAIN).setPackage("moe.shizuku.privileged.api")
            val list = context.packageManager.queryIntentActivities(intent, 0)
            if (list.isNotEmpty()) return true
        } catch (ignored: Exception) {}

        try {
            if (context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api") != null) {
                return true
            }
        } catch (ignored: Exception) {}

        return false
    }

    suspend fun executeCommand(command: String): CommandLogEntry = withContext(Dispatchers.IO) {
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val id = UUID.randomUUID().toString()

        if (_isSimulatedMode.value) {
            val simulatedOutput = generateSimulatedOutput(command)
            val entry = CommandLogEntry(
                id = id,
                timestamp = timestamp,
                command = command,
                output = simulatedOutput,
                exitCode = 0,
                isSuccess = true,
                isSimulated = true
            )
            appendLog(entry)
            return@withContext entry
        }

        // Re-check binder right before execution
        if (!isBinderReady()) {
            val entry = CommandLogEntry(
                id = id,
                timestamp = timestamp,
                command = command,
                output = "Shizuku binder not connected or permission not granted.",
                exitCode = -1,
                isSuccess = false,
                isSimulated = false
            )
            appendLog(entry)
            return@withContext entry
        }

        try {
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcessMethod.isAccessible = true
            val process = newProcessMethod.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as Process

            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))

            val output = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            while (errorReader.readLine().also { line = it } != null) {
                output.append("[ERR] ").append(line).append("\n")
            }

            val exitCode = process.waitFor()
            val text = output.toString().trim()
            val finalOutput = if (text.isEmpty()) {
                if (exitCode == 0) "OK (exit 0)" else "Exited with code $exitCode"
            } else text

            val entry = CommandLogEntry(
                id = id,
                timestamp = timestamp,
                command = command,
                output = finalOutput,
                exitCode = exitCode,
                isSuccess = exitCode == 0,
                isSimulated = false
            )
            appendLog(entry)
            entry
        } catch (t: Throwable) {
            val entry = CommandLogEntry(
                id = id,
                timestamp = timestamp,
                command = command,
                output = "Execution failed: ${t.localizedMessage}",
                exitCode = -1,
                isSuccess = false,
                isSimulated = false
            )
            appendLog(entry)
            entry
        }
    }

    private fun isBinderReady(): Boolean {
        return try {
            Shizuku.pingBinder() && (
                if (Shizuku.isPreV11()) {
                    context.checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED
                } else {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                }
            )
        } catch (t: Throwable) {
            false
        }
    }

    private fun generateSimulatedOutput(command: String): String {
        return when {
            command.contains("wifi_scan_always_enabled") -> "Simulated: wifi_scan_always_enabled updated"
            command.contains("set-scan-always-available") -> "Simulated: Wi-Fi background scan policy updated"
            command.contains("force-low-latency-mode") -> "Simulated: Wi-Fi HAL low-latency mode updated"
            command.contains("force-hi-perf-mode") -> "Simulated: Wi-Fi high-performance lock updated"
            command.contains("private_dns") -> "Simulated: Private DNS specifier updated"
            command.contains("mobile_data_always_on") -> "Simulated: Mobile data always-on updated"
            command.contains("tcp_default_init_rwnd") -> "Simulated: TCP initial receive window set to 60"
            command.contains("game mode") -> "Simulated: GameManagerService mode updated"
            command.contains("set-standby-bucket") -> "Simulated: App standby bucket updated"
            command.contains("appops set") -> "Simulated: AppOps background execution policy updated"
            command.contains("restrict-background") -> "Simulated: NetPolicy background data policy updated"
            command.contains("force-stop") -> "Simulated: Background package stopped"
            command.contains("kill-all") -> "Simulated: Cached background processes cleared"
            else -> "Simulated: Executed successfully"
        }
    }

    private fun appendLog(entry: CommandLogEntry) {
        val current = _commandLogs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 120) {
            current.removeAt(current.lastIndex)
        }
        _commandLogs.value = current
    }

    fun clearLogs() {
        _commandLogs.value = emptyList()
    }

    fun destroy() {
        autoCheckJob?.cancel()
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionListener)
        } catch (t: Throwable) {
            // ignore
        }
    }

    companion object {
        const val REQUEST_CODE_SHIZUKU = 1001
    }
}
