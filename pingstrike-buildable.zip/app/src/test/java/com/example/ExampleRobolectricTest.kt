package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.GameApp
import com.example.model.OptimizationToggles
import com.example.model.PingQuality
import com.example.model.PingServer
import com.example.model.ShizukuState
import com.example.shizuku.ShizukuManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PingStrike", appName)
  }

  @Test
  fun `verify ping quality calculation`() {
    val serverFast = PingServer("test", "Fast Server", "US", "1.1.1.1", "Edge", 22)
    assertEquals(PingQuality.EXCELLENT, serverFast.quality)

    val serverModerate = PingServer("test2", "Mod Server", "US", "1.1.1.1", "Edge", 75)
    assertEquals(PingQuality.FAIR, serverModerate.quality)
  }

  @Test
  fun `verify shizuku simulation mode execution`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = ShizukuManager(context)
    manager.setSimulationMode(true)
    assertEquals(ShizukuState.SIMULATED, manager.shizukuState.value)

    val result = manager.executeCommand("settings put global wifi_scan_always_enabled 0")
    assertTrue(result.isSuccess)
    assertTrue(result.isSimulated)
    assertNotNull(result.output)
  }
}
