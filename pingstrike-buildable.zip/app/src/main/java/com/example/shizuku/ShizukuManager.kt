package com.example.shizuku

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.example.model.CommandLogEntry
import com.example.model.ShizukuState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ShizukuManager(private val context: Context) {

    private val _shizukuState = MutableStateFlow(ShizukuState.STOPPED)
    val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

    private val _commandLogs = MutableStateFlow<List<CommandLogEntry>>(emptyList())
    val commandLogs: StateFlow<List<CommandLogEntry>> = _commandLogs.asStateFlow()

    private val _isSimulatedMode = MutableStateFlow(false)
    val isSimulatedMode: StateFlow<Boolean> = _isSimulatedMode.asStateFlow()

    private val _detailedStatusMessage = MutableStateFlow("Initializing Shizuku...")
    val detailedStatusMessage: StateFlow<String> = _detailedStatusMessage.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main)
    private var autoCheckJob: Job? = null

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE_SHIZUKU) {
            checkStatus()
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        checkStatus()
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionListener)
        } catch (t: Throwable) {
            Log.w("ShizukuManager", "Failed to add Shizuku listeners: ${t.message}")
        }
        checkStatus()
        startAutoCheckLoop()
    }

    private fun startAutoCheckLoop() {
        autoCheckJob?.cancel()
        autoCheckJob = scope.launch {
            while (isActive) {
                delay(3000)
                // If not connected yet and not in explicit simulation mode, re-poll
                if (!_isSimulatedMode.value && _shizukuState.value != ShizukuState.CONNECTED) {
                    checkStatus()
                }
            }
        }
    }

    fun setSimulationMode(enabled: Boolean) {
        _isSimulatedMode.value = enabled
        if (enabled) {
            _shizukuState.value = ShizukuState.SIMULATED
            _detailedStatusMessage.value = "Simulated ADB environment active. All commands will run virtually."
        } else {
            checkStatus()
        }
    }

    fun checkStatus(): ShizukuState {
        if (_isSimulatedMode.value) {
            _shizukuState.value = ShizukuState.SIMULATED
            _detailedStatusMessage.value = "Virtual ADB environment active for demonstration."
            return ShizukuState.SIMULATED
        }

        val state = try {
            val ping = try {
                Shizuku.pingBinder()
            } catch (t: Throwable) {
                false
            }

            if (ping) {
                val hasPermission = try {
                    if (Shizuku.isPreV11()) {
                        context.checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED
                    } else {
                        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    }
                } catch (t: Throwable) {
                    false
                }

                if (hasPermission) {
                    val uid = try { Shizuku.getUid() } catch (e: Exception) { 2000 }
                    val ver = try { Shizuku.getVersion() } catch (e: Exception) { 13 }
                    _detailedStatusMessage.value = "Connected! Privileged ADB active (UID: $uid, API: v$ver)"
                    ShizukuState.CONNECTED
                } else {
                    _detailedStatusMessage.value = "Shizuku service is running, but PingStrike needs permission."
                    ShizukuState.PERMISSION_NEEDED
                }
            } else {
                val installed = isShizukuInstalled()
                if (installed) {
                    _detailedStatusMessage.value = "Shizuku app is installed, but the service is NOT running. Open Shizuku and tap Start."
                    ShizukuState.STOPPED
                } else {
                    _detailedStatusMessage.value = "Shizuku app not detected on device. Install Shizuku or use Simulation Mode."
                    ShizukuState.NOT_INSTALLED
                }
            }
        } catch (t: Throwable) {
            Log.e("ShizukuManager", "Error checking Shizuku status", t)
            _detailedStatusMessage.value = "Error checking status: ${t.localizedMessage}"
            ShizukuState.STOPPED
        }

        _shizukuState.value = state
        return state
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.isPreV11()) {
                    // pre-v11 permission via framework
                } else {
                    Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
                }
            } else {
                // If pingBinder is false, permission cannot be requested via binder; open Shizuku app
                openShizukuApp()
            }
        } catch (t: Throwable) {
            Log.e("ShizukuManager", "Failed to request Shizuku permission", t)
            openShizukuApp()
        }
    }

    fun openShizukuApp(): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun isShizukuInstalled(): Boolean {
        // Method 1: direct getPackageInfo
        try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            return true
        } catch (ignored: Exception) {}

        // Method 2: query main intent
        try {
            val intent = Intent(Intent.ACTION_MAIN).setPackage("moe.shizuku.privileged.api")
            val list = context.packageManager.queryIntentActivities(intent, 0)
            if (list.isNotEmpty()) return true
        } catch (ignored: Exception) {}

        // Method 3: launch intent check
        try {
            if (context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api") != null) {
                return true
            }
        } catch (ignored: Exception) {}

        return false
    }

    suspend fun executeCommand(command: String): CommandLogEntry = withContext(Dispatchers.IO) {
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val id = UUID.randomUUID().toString()

        if (_isSimulatedMode.value || _shizukuState.value != ShizukuState.CONNECTED) {
            // Simulated execution
            val simulatedOutput = generateSimulatedOutput(command)
            val entry = CommandLogEntry(
                id = id,
                timestamp = timestamp,
                command = command,
                output = simulatedOutput,
                exitCode = 0,
                isSuccess = true,
                isSimulated = true
            )
            appendLog(entry)
            return@withContext entry
        }

        try {
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcessMethod.isAccessible = true
            val process = newProcessMethod.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as Process

            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))

            val output = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            while (errorReader.readLine().also { line = it } != null) {
                output.append("[ERR] ").append(line).append("\n")
            }

            val exitCode = process.waitFor()
            val text = output.toString().trim()
            val finalOutput = if (text.isEmpty()) {
                if (exitCode == 0) "Success (Exit code: 0)" else "Command exited with code $exitCode"
            } else text

            val entry = CommandLogEntry(
                id = id,
                timestamp = timestamp,
                command = command,
                output = finalOutput,
                exitCode = exitCode,
                isSuccess = exitCode == 0,
                isSimulated = false
            )
            appendLog(entry)
            entry
        } catch (t: Throwable) {
            val entry = CommandLogEntry(
                id = id,
                timestamp = timestamp,
                command = command,
                output = "Execution failed: ${t.localizedMessage}",
                exitCode = -1,
                isSuccess = false,
                isSimulated = false
            )
            appendLog(entry)
            entry
        }
    }

    private fun generateSimulatedOutput(command: String): String {
        return when {
            command.contains("wifi_scan_always_enabled") -> "Settings global: wifi_scan_always_enabled set to 0 (Wi-Fi scan throttling disabled)"
            command.contains("force-hi-perf-mode") -> "Wi-Fi lock high-performance low-latency mode locked successfully"
            command.contains("private_dns") -> "Private DNS provider specifier successfully updated to DNS gaming resolver"
            command.contains("mobile_data_always_on") -> "Settings global: mobile_data_always_on set to 1 (Failover instant handoff)"
            command.contains("net.tcp.buffersize") -> "TCP buffer sizes updated: 524288,1048576,2097152,262144,524288,1048576"
            command.contains("game mode performance") -> "GameManagerService: Performance mode enabled for target game"
            command.contains("set-standby-bucket") && command.contains("restricted") -> "AppStandbyController: Standby bucket restricted for target package"
            command.contains("set-standby-bucket") && command.contains("active") -> "AppStandbyController: Standby bucket ACTIVE granted for target package"
            command.contains("restrict-background") -> "NetworkPolicyManager: Background data restricted for non-whitelisted apps"
            command.contains("stop-app") || command.contains("force-stop") -> "ActivityManager: Force-stopped background process"
            command.contains("ping") -> "64 bytes from 1.1.1.1: icmp_seq=1 ttl=58 time=14.2 ms"
            else -> "Command executed successfully in Shizuku environment."
        }
    }

    private fun appendLog(entry: CommandLogEntry) {
        val current = _commandLogs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 100) {
            current.removeAt(current.lastIndex)
        }
        _commandLogs.value = current
    }

    fun clearLogs() {
        _commandLogs.value = emptyList()
    }

    fun destroy() {
        autoCheckJob?.cancel()
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionListener)
        } catch (t: Throwable) {
            // ignore
        }
    }

    companion object {
        const val REQUEST_CODE_SHIZUKU = 1001
    }
}
