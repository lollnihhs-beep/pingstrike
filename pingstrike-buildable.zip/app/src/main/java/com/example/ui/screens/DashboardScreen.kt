package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.GameSelectorSheet
import com.example.ui.components.LivePingGraph
import com.example.ui.components.PingSpeedometer
import com.example.ui.components.ShizukuSetupGuideDialog
import com.example.ui.components.ShizukuStatusBar
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PingBoosterViewModel

@Composable
fun DashboardScreen(
    viewModel: PingBoosterViewModel,
    onNavigateToNetwork: () -> Unit,
    onNavigateToTasks: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shizukuState by viewModel.shizukuState.collectAsState()
    val isBoosting by viewModel.isBoosting.collectAsState()
    val isStrikeModeActive by viewModel.isStrikeModeActive.collectAsState()
    val boostStatusMessage by viewModel.boostStatusMessage.collectAsState()
    val currentPing by viewModel.currentPing.collectAsState()
    val minPing by viewModel.minPing.collectAsState()
    val maxPing by viewModel.maxPing.collectAsState()
    val jitter by viewModel.jitter.collectAsState()
    val pingHistory by viewModel.pingHistory.collectAsState()
    val selectedGame by viewModel.selectedGame.collectAsState()
    val installedGames by viewModel.installedGames.collectAsState()
    val toggles by viewModel.toggles.collectAsState()
    val networkDetails by viewModel.networkDetails.collectAsState()

    var showGameSelector by remember { mutableStateOf(false) }
    var showGuideDialog by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner with Gaming Visual
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.gaming_network_banner_1794486729537),
                contentDescription = "Esports Network Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xCC080C14),
                                Color(0xFF080C14)
                            )
                        )
                    )
            )

            // Header info over banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "PINGSTRIKE",
                            color = CyberCyan,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(NeonGreen, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "SHIZUKU CORE",
                                color = Color.Black,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Text(
                        text = "System-Level Network & Task Accelerator",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                // Active network badge
                Row(
                    modifier = Modifier
                        .background(DarkSurfaceVariant.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = if (networkDetails.isWifi) "${networkDetails.frequencyMhz / 1000}GHz" else "4G/5G",
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val detailedStatus by viewModel.shizukuManager.detailedStatusMessage.collectAsState()

            // Shizuku Status Banner
            ShizukuStatusBar(
                state = shizukuState,
                detailedMessage = detailedStatus,
                onRequestPermission = { viewModel.shizukuManager.requestPermission() },
                onOpenGuide = { showGuideDialog = true },
                onOpenShizukuApp = { viewModel.shizukuManager.openShizukuApp() },
                onRefreshStatus = { viewModel.shizukuManager.checkStatus() },
                onToggleSimulation = { viewModel.shizukuManager.setSimulationMode(it) }
            )

            // Speedometer Arc
            PingSpeedometer(
                currentPing = currentPing,
                minPing = minPing,
                maxPing = maxPing,
                jitter = jitter,
                isBoosting = isBoosting
            )

            // Selected Target Game Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
                    .border(1.dp, if (isStrikeModeActive) CyberCyan else DarkBorder, RoundedCornerShape(16.dp))
                    .clickable { showGameSelector = true }
                    .padding(14.dp)
                    .testTag("target_game_card"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(
                                Brush.linearGradient(listOf(CyberCyan.copy(alpha = 0.3f), NeonPurple.copy(alpha = 0.3f))),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = selectedGame.name,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (isStrikeModeActive) {
                                Box(
                                    modifier = Modifier
                                        .background(NeonGreen, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "PRIORITY 120 FPS",
                                        color = Color.Black,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                        Text(
                            text = "Target Package: ${selectedGame.packageName}",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }
                }

                OutlinedButton(
                    onClick = { showGameSelector = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                    modifier = Modifier.testTag("switch_game_button")
                ) {
                    Text("Change", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Giant 1-Tap Strike Mode Activator Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (isStrikeModeActive) {
                            Brush.horizontalGradient(listOf(Color(0xFF042F2E), Color(0xFF0C2433)))
                        } else {
                            Brush.horizontalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E1B4B)))
                        },
                        RoundedCornerShape(18.dp)
                    )
                    .border(
                        width = if (isStrikeModeActive) 2.dp else 1.dp,
                        brush = if (isStrikeModeActive) {
                            Brush.horizontalGradient(listOf(NeonGreen, CyberCyan))
                        } else {
                            Brush.horizontalGradient(listOf(CyberCyan.copy(alpha = pulseGlow), NeonPurple.copy(alpha = pulseGlow)))
                        },
                        shape = RoundedCornerShape(18.dp)
                    )
                    .clickable(enabled = !isBoosting) {
                        viewModel.toggleStrikeMode()
                    }
                    .padding(18.dp)
                    .testTag("strike_mode_button")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(
                                    if (isStrikeModeActive) NeonGreen else CyberCyan,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isBoosting) {
                                CircularProgressIndicator(
                                    color = Color.Black,
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 3.dp
                                )
                            } else {
                                Icon(
                                    imageVector = if (isStrikeModeActive) Icons.Default.Check else Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = if (isStrikeModeActive) "STRIKE MODE ACTIVE" else "ACTIVATE STRIKE MODE",
                                color = if (isStrikeModeActive) NeonGreen else TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = if (isStrikeModeActive) {
                                    "Tap to restore default system network settings"
                                } else {
                                    "1-Tap low ping, background freeze & TCP burst"
                                },
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = if (isStrikeModeActive) Icons.Default.PowerSettingsNew else Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = if (isStrikeModeActive) NeonGreen else CyberCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Status message readout during boosting
            AnimatedVisibility(visible = boostStatusMessage.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceCard, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (isStrikeModeActive) NeonGreen else CyberCyan, CircleShape)
                        )
                        Text(
                            text = boostStatusMessage,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 2
                        )
                    }
                }
            }

            // Live Stability Graph
            LivePingGraph(history = pingHistory)

            // Optimization Quick Status Matrix
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Active Optimization Profiles",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Configure",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onNavigateToNetwork() }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickStatusBadge(
                        title = "Wi-Fi Scan Spikes",
                        status = if (toggles.disableWifiScanSpikes) "Throttled" else "Normal",
                        isActive = toggles.disableWifiScanSpikes,
                        modifier = Modifier.weight(1f)
                    )
                    QuickStatusBadge(
                        title = "Gaming DNS",
                        status = "Cloudflare 1.1",
                        isActive = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickStatusBadge(
                        title = "TCP Low Latency",
                        status = if (toggles.tcpBufferPacing) "2MB Pacing" else "Standard",
                        isActive = toggles.tcpBufferPacing,
                        modifier = Modifier.weight(1f)
                    )
                    QuickStatusBadge(
                        title = "Background Tasks",
                        status = if (isStrikeModeActive) "Frozen (8 Apps)" else "Normal",
                        isActive = isStrikeModeActive,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    if (showGameSelector) {
        GameSelectorSheet(
            games = installedGames,
            selectedGame = selectedGame,
            onSelectGame = { viewModel.selectGame(it) },
            onDismiss = { showGameSelector = false }
        )
    }

    if (showGuideDialog) {
        ShizukuSetupGuideDialog(
            isSimulationMode = shizukuState == com.example.model.ShizukuState.SIMULATED,
            onToggleSimulation = { viewModel.shizukuManager.setSimulationMode(it) },
            onDismiss = { showGuideDialog = false }
        )
    }
}

@Composable
private fun QuickStatusBadge(
    title: String,
    status: String,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(DarkSurfaceVariant, RoundedCornerShape(10.dp))
            .border(1.dp, if (isActive) NeonGreen.copy(alpha = 0.3f) else DarkBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Text(text = title, color = TextMuted, fontSize = 10.sp)
        Text(
            text = status,
            color = if (isActive) NeonGreen else TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
