package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShizukuSetupGuideDialog(
    isSimulationMode: Boolean,
    onToggleSimulation: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Fix 'Not Connected'", "Wireless ADB", "PC Terminal", "Root Mode")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("shizuku_guide_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Shizuku Diagnostics & Setup",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Step-by-step activation for system network control",
                            color = CyberCyan,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkSurfaceCard,
                    contentColor = CyberCyan,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = CyberCyan
                        )
                    }
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Content based on tab
                when (selectedTab) {
                    0 -> TroubleshootingGuide(context)
                    1 -> WirelessAdbGuide(context)
                    2 -> ComputerAdbGuide(context)
                    3 -> RootGuide(context)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                            if (intent != null) {
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(intent)
                            } else {
                                val browserIntent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("https://github.com/RikkaApps/Shizuku/releases")
                                )
                                context.startActivity(browserIntent)
                            }
                        },
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open Shizuku App", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            onToggleSimulation(!isSimulationMode)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isSimulationMode) NeonGreen else NeonPurple
                        )
                    ) {
                        Text(
                            text = if (isSimulationMode) "Use Real ADB" else "Test Simulation",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TroubleshootingGuide(context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E1528), RoundedCornerShape(10.dp))
                .border(1.dp, NeonAmber.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "Why is it saying 'Not Connected'?",
                    color = NeonAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Simply installing Shizuku is only Step 1. Android requires you to actually START the Shizuku background service inside the Shizuku app.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        GuideStep(
            number = "1",
            title = "Open the Shizuku App",
            description = "Tap the 'Open Shizuku App' button below. Look at the top banner: Does it say 'Shizuku is running' or 'Shizuku is not running'?"
        )

        GuideStep(
            number = "2",
            title = "If it says 'Shizuku is not running'",
            description = "You must start it! Tap 'Start' under 'Start via Wireless Debugging' (Android 11+) or 'Start with Root'."
        )

        GuideStep(
            number = "3",
            title = "If Shizuku IS running, check permissions",
            description = "Inside Shizuku, tap 'Authorized Applications' and ensure PingStrike toggle is turned ON."
        )

        GuideStep(
            number = "4",
            title = "Xiaomi / Redmi / POCO users",
            description = "You MUST enable 'USB debugging (Security settings)' in Developer Options, otherwise Android blocks permission dialogs."
        )

        GuideStep(
            number = "5",
            title = "Want to test ping optimizations immediately?",
            description = "Tap 'Test Simulation' below to test with full virtual ADB privileges without configuring wireless debugging."
        )
    }
}

@Composable
private fun WirelessAdbGuide(context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GuideStep(
            number = "1",
            title = "Connect to Wi-Fi",
            description = "Connect your phone to Wi-Fi or turn on your Personal Hotspot."
        )
        GuideStep(
            number = "2",
            title = "Enable Developer Options",
            description = "Go to Settings → About Phone → Tap 'Build Number' 7 times until unlocked."
        )
        GuideStep(
            number = "3",
            title = "Pair in Shizuku",
            description = "Open Shizuku app → Tap 'Pairing' → In Developer Options, enable 'Wireless Debugging' → 'Pair device with pairing code' → enter 6-digit code in notification."
        )
        GuideStep(
            number = "4",
            title = "Tap Start in Shizuku",
            description = "Once paired, return to Shizuku and tap 'Start'. Shizuku will show 'Shizuku is running (v13, adb)'!"
        )
    }
}

@Composable
private fun ComputerAdbGuide(context: Context) {
    val adbCmd = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh"

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GuideStep(
            number = "1",
            title = "Connect Phone to PC via USB",
            description = "Enable 'USB Debugging' in Developer Options."
        )
        GuideStep(
            number = "2",
            title = "Run ADB Command",
            description = "Open Command Prompt, PowerShell, or Terminal on your computer and run:"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF06090F), RoundedCornerShape(10.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
                .clickable { copyToClipboard(context, adbCmd) }
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = adbCmd,
                    color = CyberCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy Command",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        GuideStep(
            number = "3",
            title = "Return to PingStrike",
            description = "Shizuku will immediately transition to 'Connected' in PingStrike!"
        )
    }
}

@Composable
private fun RootGuide(context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GuideStep(
            number = "1",
            title = "Root Privileges (Magisk / KernelSU / APatch)",
            description = "If your device is rooted, open Shizuku app and tap 'Start' under 'Start with Root'."
        )
        GuideStep(
            number = "2",
            title = "Grant Superuser",
            description = "Tap Grant when prompted by your root manager."
        )
        GuideStep(
            number = "3",
            title = "Authorize PingStrike",
            description = "Return to PingStrike and tap 'Authorize' on the top status banner."
        )
    }
}

@Composable
private fun GuideStep(number: String, title: String, description: String) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .background(DarkSurfaceVariant, RoundedCornerShape(6.dp))
                .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = CyberCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = description,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("ADB Command", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Command copied to clipboard", Toast.LENGTH_SHORT).show()
}
