package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommandLogEntry
import com.example.model.ShizukuState
import com.example.ui.components.ShizukuSetupGuideDialog
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PingBoosterViewModel

@Composable
fun ShizukuTerminalScreen(
    viewModel: PingBoosterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val shizukuState by viewModel.shizukuState.collectAsState()
    val commandLogs by viewModel.commandLogs.collectAsState()

    var customCommand by remember { mutableStateOf("") }
    var showGuide by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("shizuku_terminal_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Shizuku Shell Engine",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Privileged ADB command terminal & diagnostics",
                    color = CyberCyan,
                    fontSize = 11.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(
                    onClick = { showGuide = true },
                    modifier = Modifier
                        .background(DarkSurfaceVariant, CircleShape)
                        .size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = "Shizuku Guide",
                        tint = CyberCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.shizukuManager.clearLogs() },
                    modifier = Modifier
                        .background(DarkSurfaceVariant, CircleShape)
                        .size(36.dp)
                        .testTag("clear_logs_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ClearAll,
                        contentDescription = "Clear logs",
                        tint = TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Shizuku Environment Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(14.dp))
                .border(
                    1.dp,
                    if (shizukuState == ShizukuState.CONNECTED) NeonGreen.copy(alpha = 0.5f) else DarkBorder,
                    RoundedCornerShape(14.dp)
                )
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            when (shizukuState) {
                                ShizukuState.CONNECTED -> NeonGreen.copy(alpha = 0.2f)
                                ShizukuState.SIMULATED -> NeonPurple.copy(alpha = 0.2f)
                                else -> NeonAmber.copy(alpha = 0.2f)
                            },
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = when (shizukuState) {
                            ShizukuState.CONNECTED -> NeonGreen
                            ShizukuState.SIMULATED -> NeonPurple
                            else -> NeonAmber
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                val detailedMsg by viewModel.shizukuManager.detailedStatusMessage.collectAsState()
                Column {
                    Text(
                        text = when (shizukuState) {
                            ShizukuState.CONNECTED -> "Binder Active (UID 2000 ADB)"
                            ShizukuState.SIMULATED -> "Simulated ADB Environment"
                            ShizukuState.PERMISSION_NEEDED -> "Permission Needed (Tap Authorize)"
                            ShizukuState.STOPPED -> "Shizuku Service Not Running"
                            ShizukuState.NOT_INSTALLED -> "Not Installed"
                        },
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = detailedMsg,
                        color = TextSecondary,
                        fontSize = 10.sp,
                        maxLines = 2
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(
                    onClick = { viewModel.shizukuManager.checkStatus() },
                    modifier = Modifier
                        .background(DarkSurfaceVariant, CircleShape)
                        .size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Shizuku",
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }

                OutlinedButton(
                    onClick = {
                        viewModel.shizukuManager.setSimulationMode(shizukuState != ShizukuState.SIMULATED)
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (shizukuState == ShizukuState.SIMULATED) NeonPurple else CyberCyan
                    ),
                    modifier = Modifier.testTag("toggle_simulation_button")
                ) {
                    Text(
                        text = if (shizukuState == ShizukuState.SIMULATED) "Exit Sim" else "Sim Mode",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Quick Command Presets Row
        Text(
            text = "QUICK SCRIPT PRESETS",
            color = TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PresetButton(
                title = "Anti-Spike Wi-Fi",
                command = "settings put global wifi_scan_always_enabled 0",
                onClick = { viewModel.executeCustomCommand("settings put global wifi_scan_always_enabled 0") },
                modifier = Modifier.weight(1f)
            )
            PresetButton(
                title = "TCP Buffers",
                command = "setprop net.tcp.buffersize.wifi 524288,1048576,2097152,262144,524288,1048576",
                onClick = { viewModel.executeCustomCommand("setprop net.tcp.buffersize.wifi 524288,1048576,2097152,262144,524288,1048576") },
                modifier = Modifier.weight(1f)
            )
            PresetButton(
                title = "Reset Defaults",
                command = "settings put global wifi_scan_always_enabled 1",
                onClick = { viewModel.executeCustomCommand("settings put global wifi_scan_always_enabled 1") },
                modifier = Modifier.weight(1f)
            )
        }

        // Command Input Field
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = customCommand,
                onValueChange = { customCommand = it },
                placeholder = {
                    Text(
                        "cmd wifi ... or settings get global ...",
                        color = TextMuted,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("custom_command_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            Button(
                onClick = {
                    if (customCommand.isNotBlank()) {
                        viewModel.executeCustomCommand(customCommand)
                        customCommand = ""
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyberCyan,
                    contentColor = Color.Black
                ),
                modifier = Modifier
                    .size(48.dp)
                    .testTag("run_command_button"),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Execute Command",
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Terminal Output Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "EXECUTION CONSOLE (${commandLogs.size} ENTRIES)",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            if (commandLogs.isNotEmpty()) {
                Text(
                    text = "Copy Log",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable {
                        val text = commandLogs.joinToString("\n\n") {
                            "[${it.timestamp}] $ ${it.command}\n${it.output}"
                        }
                        copyToClipboard(context, text)
                    }
                )
            }
        }

        // Scrollable Terminal Logs
        if (commandLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF06090F), RoundedCornerShape(12.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No commands executed yet",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Run a script preset or enter an ADB command above",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF06090F), RoundedCornerShape(12.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(commandLogs, key = { it.id }) { log ->
                    TerminalLogCard(log = log)
                }
            }
        }
    }

    if (showGuide) {
        ShizukuSetupGuideDialog(
            isSimulationMode = shizukuState == ShizukuState.SIMULATED,
            onToggleSimulation = { viewModel.shizukuManager.setSimulationMode(it) },
            onDismiss = { showGuide = false }
        )
    }
}

@Composable
private fun PresetButton(
    title: String,
    command: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(DarkSurfaceCard, RoundedCornerShape(10.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = title,
                color = CyberCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tap to execute",
                color = TextMuted,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun TerminalLogCard(log: CommandLogEntry) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
            .border(1.dp, if (log.isSuccess) Color(0xFF1E293B) else NeonRed.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = log.timestamp,
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (log.isSimulated) {
                    Box(
                        modifier = Modifier
                            .background(NeonPurple.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "SIM",
                            color = NeonPurple,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .background(
                        if (log.isSuccess) NeonGreen.copy(alpha = 0.15f) else NeonRed.copy(alpha = 0.15f),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = if (log.isSuccess) "EXIT 0" else "EXIT ${log.exitCode}",
                    color = if (log.isSuccess) NeonGreen else NeonRed,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$ ",
                color = CyberCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = log.command,
                color = TextPrimary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = log.output,
            color = if (log.isSuccess) TextSecondary else NeonRed,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 13.sp
        )
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Terminal Log", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Log copied to clipboard", Toast.LENGTH_SHORT).show()
}
