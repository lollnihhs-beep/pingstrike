package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DnsBenchmarkItem
import com.example.model.PingQuality
import com.example.model.PingServer
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PingBoosterViewModel

@Composable
fun NetworkOptimizerScreen(
    viewModel: PingBoosterViewModel,
    modifier: Modifier = Modifier
) {
    val toggles by viewModel.toggles.collectAsState()
    val dnsProviders by viewModel.dnsProviders.collectAsState()
    val servers by viewModel.gamingServers.collectAsState()
    val networkDetails by viewModel.networkDetails.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("network_optimizer_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "System Network Tuning",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Direct kernel & system settings via Shizuku",
                    color = CyberCyan,
                    fontSize = 11.sp
                )
            }

            IconButton(
                onClick = { viewModel.refreshNetworkDetails() },
                modifier = Modifier
                    .background(DarkSurfaceVariant, CircleShape)
                    .size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh telemetry",
                    tint = CyberCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Active Connection Hardware Telemetry
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (networkDetails.isWifi) Icons.Default.Wifi else Icons.Default.SignalCellularAlt,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (networkDetails.isWifi) "Wi-Fi (802.11ac/ax)" else "Cellular LTE/5G",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = networkDetails.interfaceName,
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryItem(label = "Link Speed", value = "${networkDetails.linkSpeedMbps} Mbps")
                TelemetryItem(label = "Frequency", value = "${networkDetails.frequencyMhz} MHz")
                TelemetryItem(label = "Signal", value = "${networkDetails.rssiDbm} dBm")
                TelemetryItem(label = "IP Address", value = networkDetails.ipAddress)
            }
        }

        // Section 1: Core System Network Toggles
        Text(
            text = "KERNEL & SYSTEM OPTIMIZATIONS",
            color = TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        OptimizationToggleCard(
            title = "Block Wi-Fi Scan Latency Spikes",
            description = "Disables Android background Wi-Fi scanning (`wifi_scan_always_enabled=0`). Stops the periodic 150-300ms ping spikes caused by background beacon probes.",
            icon = Icons.Default.Router,
            isChecked = toggles.disableWifiScanSpikes,
            onCheckedChange = { viewModel.updateToggle { copy(disableWifiScanSpikes = it) } },
            badgeText = "CRITICAL FOR GAMING"
        )

        OptimizationToggleCard(
            title = "Wi-Fi High-Performance Low-Latency",
            description = "Locks Wi-Fi chip into continuous low-latency burst mode (`cmd wifi force-hi-perf-mode 1`) and disables Wi-Fi sleep timeouts.",
            icon = Icons.Default.Speed,
            isChecked = toggles.wifiLowLatencyMode,
            onCheckedChange = { viewModel.updateToggle { copy(wifiLowLatencyMode = it) } },
            badgeText = "SHIZUKU"
        )

        OptimizationToggleCard(
            title = "Mobile Data Instant Failover",
            description = "Maintains cellular data radio in connected standby (`mobile_data_always_on=1`). Eliminates disconnect timeouts if Wi-Fi packets drop.",
            icon = Icons.Default.SignalCellularAlt,
            isChecked = toggles.mobileDataAlwaysOn,
            onCheckedChange = { viewModel.updateToggle { copy(mobileDataAlwaysOn = it) } },
            badgeText = "FAILOVER"
        )

        OptimizationToggleCard(
            title = "TCP Socket & Buffer Pacing",
            description = "Sets Linux TCP window sizes and receive buffers (`net.tcp.buffersize.wifi=524288,1048576,2097152`) for low bufferbloat and gaming packet bursts.",
            icon = Icons.Default.Tune,
            isChecked = toggles.tcpBufferPacing,
            onCheckedChange = { viewModel.updateToggle { copy(tcpBufferPacing = it) } },
            badgeText = "SYS PROP"
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Section 2: Private Gaming DNS Resolver Benchmark
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "GAMING DNS RESOLVER",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Route game queries through ultra-fast edge nodes",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            OutlinedButton(
                onClick = { viewModel.benchmarkDns() },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                modifier = Modifier.testTag("benchmark_dns_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Test Latencies", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            dnsProviders.forEach { dns ->
                DnsItemCard(
                    item = dns,
                    onSelect = { viewModel.selectDns(dns) }
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Section 3: Gaming Regional Servers Ping Matrix
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "REGIONAL GAMING SERVERS MATRIX",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Live ICMP & Socket ping to major gaming clusters",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            IconButton(
                onClick = { viewModel.benchmarkServers() },
                modifier = Modifier
                    .background(DarkSurfaceVariant, CircleShape)
                    .size(34.dp)
                    .testTag("refresh_servers_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh servers",
                    tint = CyberCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            servers.forEach { server ->
                ServerPingRow(server = server)
            }
        }
    }
}

@Composable
private fun OptimizationToggleCard(
    title: String,
    description: String,
    icon: ImageVector,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    badgeText: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceCard, RoundedCornerShape(14.dp))
            .border(1.dp, if (isChecked) CyberCyan.copy(alpha = 0.4f) else DarkBorder, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(if (isChecked) CyberCyan.copy(alpha = 0.15f) else DarkSurfaceVariant, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isChecked) CyberCyan else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .background(
                                if (isChecked) NeonGreen.copy(alpha = 0.2f) else DarkSurfaceVariant,
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = badgeText,
                            color = if (isChecked) NeonGreen else TextMuted,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = description,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = CyberCyan,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = DarkSurfaceVariant
            ),
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
private fun DnsItemCard(
    item: DnsBenchmarkItem,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (item.isSelected) Color(0xFF0C2433) else DarkSurfaceCard, RoundedCornerShape(12.dp))
            .border(1.dp, if (item.isSelected) CyberCyan else DarkBorder, RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(if (item.isSelected) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceVariant, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Dns,
                    contentDescription = null,
                    tint = if (item.isSelected) CyberCyan else TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }

            Column {
                Text(
                    text = item.name,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = item.description,
                    color = TextSecondary,
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (item.isTesting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = CyberCyan,
                    strokeWidth = 2.dp
                )
            } else if (item.latencyMs > 0) {
                val pingColor = if (item.latencyMs < 20) NeonGreen else if (item.latencyMs < 40) CyberCyan else NeonAmber
                Box(
                    modifier = Modifier
                        .background(pingColor.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${item.latencyMs}ms",
                        color = pingColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            if (item.isSelected) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .background(NeonGreen, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Active",
                        tint = Color.Black,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ServerPingRow(server: PingServer) {
    val quality = server.quality
    val pingColor = when (quality) {
        PingQuality.EXCELLENT -> NeonGreen
        PingQuality.GOOD -> CyberCyan
        PingQuality.FAIR -> NeonAmber
        PingQuality.POOR -> NeonRed
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceCard, RoundedCornerShape(12.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(pingColor, CircleShape)
            )

            Column {
                Text(
                    text = server.name,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${server.region} • ${server.host}",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                if (server.isTesting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        color = CyberCyan,
                        strokeWidth = 2.dp
                    )
                } else if (server.currentPingMs > 0) {
                    Text(
                        text = "${server.currentPingMs} ms",
                        color = pingColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "±${server.jitterMs}ms jitter",
                        color = TextMuted,
                        fontSize = 9.sp
                    )
                } else {
                    Text(
                        text = "Timeout",
                        color = NeonRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryItem(label: String, value: String) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 9.sp)
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
