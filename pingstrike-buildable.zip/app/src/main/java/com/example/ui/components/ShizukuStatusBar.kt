package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ShizukuState
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShizukuStatusBar(
    state: ShizukuState,
    detailedMessage: String = "",
    onRequestPermission: () -> Unit,
    onOpenGuide: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onRefreshStatus: () -> Unit,
    onToggleSimulation: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val (statusColor, statusTitle, statusSub, icon) = when (state) {
        ShizukuState.CONNECTED -> Quadruple(
            NeonGreen,
            "Shizuku Connected (UID: 2000)",
            "Privileged ADB shell active & executing system optimizations",
            Icons.Default.CheckCircle
        )
        ShizukuState.PERMISSION_NEEDED -> Quadruple(
            NeonAmber,
            "Service Running (Needs Permission)",
            "Shizuku is running! Tap 'Authorize' to grant ADB privileges",
            Icons.Default.Security
        )
        ShizukuState.SIMULATED -> Quadruple(
            NeonPurple,
            "Simulated ADB Active (Ready to Test)",
            "Virtual privileged ADB environment active for demonstration",
            Icons.Default.Info
        )
        ShizukuState.STOPPED -> Quadruple(
            NeonAmber,
            "Shizuku Installed (Service Not Started)",
            "App detected, but daemon is stopped. Open Shizuku & tap 'Start'",
            Icons.Default.Warning
        )
        ShizukuState.NOT_INSTALLED -> Quadruple(
            NeonRed,
            "Shizuku App Not Detected",
            "Install Shizuku APK or switch to Simulation Mode",
            Icons.Default.Warning
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
            .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("shizuku_status_bar"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(statusColor.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column {
                    Text(
                        text = statusTitle,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = statusSub,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                }
            }

            IconButton(
                onClick = onRefreshStatus,
                modifier = Modifier
                    .background(DarkSurfaceVariant, CircleShape)
                    .size(32.dp)
                    .testTag("refresh_shizuku_status")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Check connection",
                    tint = CyberCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Action Row depending on state
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            when (state) {
                ShizukuState.STOPPED -> {
                    Button(
                        onClick = onOpenShizukuApp,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.weight(1.3f).testTag("open_shizuku_app_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open Shizuku & Start", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onOpenGuide,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        modifier = Modifier.weight(0.9f).testTag("setup_guide_button")
                    ) {
                        Text("Setup Guide", fontSize = 11.sp)
                    }
                }
                ShizukuState.PERMISSION_NEEDED -> {
                    ElevatedButton(
                        onClick = onRequestPermission,
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = NeonAmber,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("grant_shizuku_button")
                    ) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Grant ADB Permission to PingStrike", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                ShizukuState.NOT_INSTALLED -> {
                    OutlinedButton(
                        onClick = onOpenGuide,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                        modifier = Modifier.weight(1f).testTag("install_shizuku_button")
                    ) {
                        Text("How to Install", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onToggleSimulation(true) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonPurple,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.weight(1f).testTag("simulate_button")
                    ) {
                        Text("Test via Simulation", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                ShizukuState.SIMULATED -> {
                    Text(
                        text = "Running virtual ADB. To use real Shizuku, start it in the Shizuku app.",
                        color = TextMuted,
                        fontSize = 10.sp,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedButton(
                        onClick = { onToggleSimulation(false) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonPurple),
                        modifier = Modifier.testTag("exit_sim_button")
                    ) {
                        Text("Switch to Real Shizuku", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                ShizukuState.CONNECTED -> {
                    Text(
                        text = "System network rules, Wi-Fi high-perf mode & task freezing ready.",
                        color = NeonGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedButton(
                        onClick = onOpenGuide,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
                    ) {
                        Text("Info", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
