package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun LivePingGraph(
    history: List<Int>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("live_ping_graph")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(NeonGreen, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "LIVE",
                        color = Color.Black,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    text = "Latency Stability Waveform",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "${history.lastOrNull() ?: 0} ms",
                color = CyberCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .padding(top = 10.dp)
        ) {
            if (history.size < 2) return@Canvas

            val w = size.width
            val h = size.height
            val maxPingVal = (history.maxOrNull()?.coerceAtLeast(60) ?: 60).toFloat()
            val minPingVal = (history.minOrNull()?.coerceAtMost(10) ?: 10).toFloat()
            val range = (maxPingVal - minPingVal).coerceAtLeast(10f)

            // Draw horizontal guide lines (30ms, 60ms)
            val lineY30 = h - ((30f - minPingVal) / range * h).coerceIn(0f, h)
            drawLine(
                color = Color(0xFF1E293B),
                start = Offset(0f, lineY30),
                end = Offset(w, lineY30),
                strokeWidth = 1.dp.toPx()
            )

            val stepX = w / (history.size - 1)
            val path = Path()
            val fillPath = Path()

            history.forEachIndexed { index, ping ->
                val x = index * stepX
                val normalizedY = 1f - ((ping - minPingVal) / range).coerceIn(0f, 1f)
                val y = normalizedY * (h - 10.dp.toPx()) + 5.dp.toPx()

                if (index == 0) {
                    path.moveTo(x, y)
                    fillPath.moveTo(x, h)
                    fillPath.lineTo(x, y)
                } else {
                    val prevX = (index - 1) * stepX
                    val prevNormY = 1f - ((history[index - 1] - minPingVal) / range).coerceIn(0f, 1f)
                    val prevY = prevNormY * (h - 10.dp.toPx()) + 5.dp.toPx()

                    // Cubic bezier smooth curve
                    val controlX1 = prevX + (x - prevX) / 2
                    val controlX2 = prevX + (x - prevX) / 2
                    path.cubicTo(controlX1, prevY, controlX2, y, x, y)
                    fillPath.cubicTo(controlX1, prevY, controlX2, y, x, y)
                }
            }

            fillPath.lineTo(w, h)
            fillPath.close()

            // Draw filled gradient area
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(CyberCyan.copy(alpha = 0.28f), Color.Transparent),
                    startY = 0f,
                    endY = h
                )
            )

            // Draw stroke line
            drawPath(
                path = path,
                brush = Brush.horizontalGradient(
                    colors = listOf(NeonGreen, CyberCyan)
                ),
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw latest point dot
            val lastX = w
            val lastY = (1f - ((history.last() - minPingVal) / range).coerceIn(0f, 1f)) * (h - 10.dp.toPx()) + 5.dp.toPx()
            drawCircle(color = CyberCyan.copy(alpha = 0.4f), radius = 6.dp.toPx(), center = Offset(lastX, lastY))
            drawCircle(color = Color.White, radius = 3.dp.toPx(), center = Offset(lastX, lastY))
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "← 45s ago", color = TextMuted, fontSize = 9.sp)
            Text(text = "Zero packet jitter target", color = TextMuted, fontSize = 9.sp)
            Text(text = "Now →", color = TextMuted, fontSize = 9.sp)
        }
    }
}
