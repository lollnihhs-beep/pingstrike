package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PingStrikeColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color(0xFF031B26),
    primaryContainer = Color(0xFF063546),
    onPrimaryContainer = CyberCyan,
    secondary = NeonPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF3B1569),
    onSecondaryContainer = Color(0xFFE9D5FF),
    tertiary = NeonGreen,
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFF064E3B),
    onTertiaryContainer = NeonGreen,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    error = NeonRed,
    onError = Color.White
)

@Composable
fun PingStrikeTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PingStrikeColorScheme,
        typography = Typography,
        content = content
    )
}
