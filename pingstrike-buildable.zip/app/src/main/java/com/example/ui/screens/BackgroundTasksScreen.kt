package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DataSaverOn
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BackgroundProcessItem
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PingBoosterViewModel

@Composable
fun BackgroundTasksScreen(
    viewModel: PingBoosterViewModel,
    modifier: Modifier = Modifier
) {
    val backgroundApps by viewModel.backgroundApps.collectAsState()
    val toggles by viewModel.toggles.collectAsState()
    val totalRamFreed = backgroundApps.filter { it.isFrozen }.sumOf { it.estimatedRamMb }
    val frozenCount = backgroundApps.count { it.isFrozen }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("background_tasks_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Background Task Manager",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "App standby buckets & background data throttle",
                    color = CyberCyan,
                    fontSize = 11.sp
                )
            }

            Box(
                modifier = Modifier
                    .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "$frozenCount / ${backgroundApps.size} Frozen",
                    color = if (frozenCount > 0) NeonGreen else TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Summary Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(16.dp))
                .border(1.dp, if (frozenCount > 0) NeonGreen.copy(alpha = 0.5f) else DarkBorder, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Estimated RAM & Bandwidth Freed",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = if (totalRamFreed > 0) "${totalRamFreed}" else "0",
                        color = if (totalRamFreed > 0) NeonGreen else TextPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "MB RAM",
                        color = TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                Text(
                    text = if (frozenCount > 0) "Standby bucket: RESTRICTED" else "No apps frozen",
                    color = if (frozenCount > 0) CyberCyan else TextMuted,
                    fontSize = 10.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (frozenCount > 0) {
                    OutlinedButton(
                        onClick = { viewModel.unfreezeAllBackgroundApps() },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted),
                        modifier = Modifier.testTag("unfreeze_all_button")
                    ) {
                        Text("Restore All", fontSize = 11.sp)
                    }
                }

                Button(
                    onClick = { viewModel.freezeAllBackgroundApps() },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier.testTag("freeze_all_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AcUnit,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Freeze All", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Network Policy Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceCard, RoundedCornerShape(14.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(if (toggles.restrictBackgroundData) NeonGreen.copy(alpha = 0.15f) else DarkSurfaceVariant, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DataSaverOn,
                        contentDescription = null,
                        tint = if (toggles.restrictBackgroundData) NeonGreen else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = "Restrict Background Data Bandwidth",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Invocates `cmd netpolicy set restrict-background true` to cut all background socket traffic except game.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Switch(
                checked = toggles.restrictBackgroundData,
                onCheckedChange = { viewModel.updateToggle { copy(restrictBackgroundData = it) } },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = NeonGreen
                )
            )
        }

        // Section Title
        Text(
            text = "HEAVY BACKGROUND NETWORKING APPS",
            color = TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // List of Background Apps
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            backgroundApps.forEach { app ->
                BackgroundAppCard(
                    app = app,
                    onToggleFreeze = { viewModel.toggleBackgroundAppFreeze(app.packageName) }
                )
            }
        }
    }
}

@Composable
private fun BackgroundAppCard(
    app: BackgroundProcessItem,
    onToggleFreeze: () -> Unit
) {
    val isFrozen = app.isFrozen

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isFrozen) Color(0xFF0C2433) else DarkSurfaceCard, RoundedCornerShape(12.dp))
            .border(
                1.dp,
                if (isFrozen) NeonGreen.copy(alpha = 0.6f) else DarkBorder,
                RoundedCornerShape(12.dp)
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(if (isFrozen) NeonGreen.copy(alpha = 0.2f) else DarkSurfaceVariant, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isFrozen) Icons.Default.AcUnit else Icons.Default.Memory,
                    contentDescription = null,
                    tint = if (isFrozen) NeonGreen else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = app.appName,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .background(DarkSurfaceVariant, RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = app.category,
                            color = TextMuted,
                            fontSize = 8.sp
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "~${app.estimatedRamMb} MB",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = "•", color = TextMuted, fontSize = 9.sp)
                    Text(
                        text = if (isFrozen) "Standby: RESTRICTED" else "Standby: ACTIVE",
                        color = if (isFrozen) NeonGreen else NeonAmber,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        OutlinedButton(
            onClick = onToggleFreeze,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = if (isFrozen) NeonGreen else CyberCyan
            ),
            modifier = Modifier.testTag("toggle_freeze_${app.appName}")
        ) {
            Text(
                text = if (isFrozen) "Throttled" else "Freeze",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
