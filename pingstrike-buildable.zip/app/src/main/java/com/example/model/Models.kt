package com.example.model

enum class ShizukuState {
    NOT_INSTALLED,
    STOPPED,
    PERMISSION_NEEDED,
    CONNECTED,
    SIMULATED
}

enum class PingQuality(val label: String, val colorHex: Long) {
    EXCELLENT("Ultra Low", 0xFF10B981), // < 35ms
    GOOD("Good", 0xFF00F0FF),          // 35 - 60ms
    FAIR("Moderate", 0xFFF59E0B),       // 60 - 100ms
    POOR("High Ping", 0xFFEF4444)       // > 100ms
}

data class PingServer(
    val id: String,
    val name: String,
    val region: String,
    val host: String,
    val category: String, // "Edge", "Esports Game", "Cloud AWS", "Custom"
    val currentPingMs: Int = -1,
    val jitterMs: Int = 0,
    val packetLossPct: Int = 0,
    val isTesting: Boolean = false
) {
    val quality: PingQuality
        get() = when {
            currentPingMs in 1..35 -> PingQuality.EXCELLENT
            currentPingMs in 36..65 -> PingQuality.GOOD
            currentPingMs in 66..105 -> PingQuality.FAIR
            else -> PingQuality.POOR
        }
}

data class DnsBenchmarkItem(
    val id: String,
    val name: String,
    val hostname: String,
    val description: String,
    val latencyMs: Int = -1,
    val isSelected: Boolean = false,
    val isTesting: Boolean = false
)

data class GameApp(
    val packageName: String,
    val name: String,
    val isInstalled: Boolean = true,
    val defaultFps: Int = 60,
    val targetFps: Int = 120,
    val isGameManagerSupported: Boolean = true
)

data class BackgroundProcessItem(
    val packageName: String,
    val appName: String,
    val category: String, // Social, Media, Shopping, Utility
    val estimatedRamMb: Int,
    val standbyBucket: String = "working_set", // active, working_set, frequent, rare, restricted
    val isFrozen: Boolean = false
)

data class OptimizationToggles(
    val disableWifiScanSpikes: Boolean = true, // settings put global wifi_scan_always_enabled 0
    val wifiLowLatencyMode: Boolean = true,    // cmd wifi force-hi-perf-mode 1 & wifi_sleep_policy 2
    val mobileDataAlwaysOn: Boolean = true,    // settings put global mobile_data_always_on 1
    val tcpBufferPacing: Boolean = true,       // net.tcp.buffersize adjustments for burst UDP/TCP gaming
    val aggressiveStandbyBuckets: Boolean = true, // am set-standby-bucket restricted for background hogs
    val gameModePerformance: Boolean = true,   // cmd game mode performance <package>
    val restrictBackgroundData: Boolean = false // cmd netpolicy set restrict-background true
)

data class NetworkDetails(
    val isWifi: Boolean = true,
    val interfaceName: String = "wlan0",
    val ipAddress: String = "192.168.1.124",
    val linkSpeedMbps: Int = 866,
    val frequencyMhz: Int = 5825, // 5GHz
    val rssiDbm: Int = -52,
    val dnsServer: String = "1.1.1.1 (Cloudflare)",
    val gateway: String = "192.168.1.1"
)

data class CommandLogEntry(
    val id: String,
    val timestamp: String,
    val command: String,
    val output: String,
    val exitCode: Int,
    val isSuccess: Boolean,
    val isSimulated: Boolean
)
