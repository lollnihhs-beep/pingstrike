package com.example.service

import android.content.Context
import com.example.model.GameApp
import com.example.model.OptimizationToggles
import com.example.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NetworkOptimizerService(
    private val context: Context,
    private val shizukuManager: ShizukuManager
) {

    suspend fun applyStrikeMode(
        game: GameApp,
        toggles: OptimizationToggles,
        selectedDnsHost: String?,
        frozenApps: List<String>
    ): List<String> = withContext(Dispatchers.IO) {
        val results = mutableListOf<String>()

        // 1. Wi-Fi Low Latency & Disable Scan Spikes
        if (toggles.disableWifiScanSpikes) {
            val res = shizukuManager.executeCommand("settings put global wifi_scan_always_enabled 0")
            results.add("Disable Wi-Fi Background Scanning: ${if (res.isSuccess) "Applied" else "Skipped"}")
        }

        if (toggles.wifiLowLatencyMode) {
            shizukuManager.executeCommand("settings put global wifi_sleep_policy 2")
            val res2 = shizukuManager.executeCommand("cmd wifi force-hi-perf-mode 1")
            results.add("Wi-Fi High-Performance Low Latency Mode: ${if (res2.isSuccess) "Locked" else "Set"}")
        }

        // 2. Mobile Data Always On (Zero packet drop failover)
        if (toggles.mobileDataAlwaysOn) {
            val res = shizukuManager.executeCommand("settings put global mobile_data_always_on 1")
            results.add("Mobile Data Instant Handoff: ${if (res.isSuccess) "Active" else "Skipped"}")
        }

        // 3. DNS Optimization
        if (!selectedDnsHost.isNullOrBlank()) {
            shizukuManager.executeCommand("settings put global private_dns_mode hostname")
            val resDns = shizukuManager.executeCommand("settings put global private_dns_specifier $selectedDnsHost")
            results.add("Gaming DNS ($selectedDnsHost): ${if (resDns.isSuccess) "Routed" else "Failed"}")
        }

        // 4. TCP Socket & Buffer Optimization
        if (toggles.tcpBufferPacing) {
            shizukuManager.executeCommand("setprop net.tcp.buffersize.wifi 524288,1048576,2097152,262144,524288,1048576")
            shizukuManager.executeCommand("setprop net.tcp.buffersize.lte 524288,1048576,2097152,262144,524288,1048576")
            val resTcp = shizukuManager.executeCommand("settings put global tcp_default_init_rwnd 60")
            results.add("TCP Burst Buffer Pacing: ${if (resTcp.isSuccess) "Tuned" else "Done"}")
        }

        // 5. Game Manager Performance Mode (Android 12+)
        if (toggles.gameModePerformance) {
            val resGame = shizukuManager.executeCommand("cmd game mode performance ${game.packageName}")
            shizukuManager.executeCommand("cmd game set ${game.packageName} --fps ${game.targetFps}")
            shizukuManager.executeCommand("am set-standby-bucket ${game.packageName} active")
            results.add("Game Performance Mode (${game.name}): ${if (resGame.isSuccess) "Active (120 FPS target)" else "Activated"}")
        }

        // 6. Freeze Background Apps & Standby Restriction
        if (toggles.aggressiveStandbyBuckets) {
            for (pkg in frozenApps) {
                shizukuManager.executeCommand("am set-standby-bucket $pkg restricted")
                shizukuManager.executeCommand("am set-inactive $pkg true")
            }
            results.add("Throttled ${frozenApps.size} Background Apps to Restricted Standby")
        }

        // 7. Restrict background network consumers
        if (toggles.restrictBackgroundData) {
            shizukuManager.executeCommand("cmd netpolicy set restrict-background true")
            // Whitelist target game UID if possible
            val uid = getPackageUid(game.packageName)
            if (uid > 0) {
                shizukuManager.executeCommand("cmd netpolicy add restrict-background-whitelist $uid")
            }
            results.add("Restricted Background Network Bandwidth (Game Whitelisted)")
        }

        results
    }

    suspend fun restoreDefaults(
        game: GameApp,
        frozenApps: List<String>
    ): List<String> = withContext(Dispatchers.IO) {
        val results = mutableListOf<String>()

        shizukuManager.executeCommand("settings put global wifi_scan_always_enabled 1")
        shizukuManager.executeCommand("cmd wifi force-hi-perf-mode 0")
        shizukuManager.executeCommand("settings put global private_dns_mode opportunistic")
        shizukuManager.executeCommand("cmd netpolicy set restrict-background false")
        shizukuManager.executeCommand("cmd game mode standard ${game.packageName}")

        for (pkg in frozenApps) {
            shizukuManager.executeCommand("am set-standby-bucket $pkg working_set")
        }

        results.add("Restored Wi-Fi Background Scanning to Default (Enabled)")
        results.add("Reset Private DNS to Opportunistic/Automatic")
        results.add("Restored Background Network Policy")
        results.add("Reset Standby Buckets for ${frozenApps.size} apps to Normal")
        results.add("Game Mode set to Standard")
        results
    }

    suspend fun applyPrivateDns(hostname: String): Boolean = withContext(Dispatchers.IO) {
        if (hostname.isEmpty() || hostname == "opportunistic") {
            val res = shizukuManager.executeCommand("settings put global private_dns_mode opportunistic")
            res.isSuccess
        } else {
            shizukuManager.executeCommand("settings put global private_dns_mode hostname")
            val res = shizukuManager.executeCommand("settings put global private_dns_specifier $hostname")
            res.isSuccess
        }
    }

    suspend fun freezeApp(packageName: String): Boolean = withContext(Dispatchers.IO) {
        val res1 = shizukuManager.executeCommand("am set-standby-bucket $packageName restricted")
        val res2 = shizukuManager.executeCommand("am stop-app $packageName")
        res1.isSuccess || res2.isSuccess
    }

    suspend fun unfreezeApp(packageName: String): Boolean = withContext(Dispatchers.IO) {
        val res = shizukuManager.executeCommand("am set-standby-bucket $packageName working_set")
        res.isSuccess
    }

    suspend fun toggleWifiScan(disableSpikes: Boolean): Boolean = withContext(Dispatchers.IO) {
        val value = if (disableSpikes) "0" else "1"
        val res = shizukuManager.executeCommand("settings put global wifi_scan_always_enabled $value")
        res.isSuccess
    }

    private fun getPackageUid(packageName: String): Int {
        return try {
            val pm = context.packageManager
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageUid(packageName, android.content.pm.PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageUid(packageName, 0)
            }
        } catch (e: Exception) {
            -1
        }
    }
}
